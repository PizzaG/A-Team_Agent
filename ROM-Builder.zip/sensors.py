#!/usr/bin/env python3
"""Hardware sensor snapshot for the ROM Builder Resource Monitor.

Pure standard library. Reads /proc and /sys directly (no root, no extra tools),
and uses optional helpers when present: ``nvidia-smi`` (NVIDIA GPUs),
``sensors -j`` (lm-sensors, fallback for temperatures) and ``lspci`` (GPU names).

The JSON shape is shared with the frontend route /api/rom-builder/resources.
Unavailable values are ``None`` so callers can show "n/a" instead of guessing.
"""
from __future__ import annotations

import glob
import json
import os
import shutil
import subprocess
import time
from datetime import datetime, timezone
from typing import Any

HOST_VRAM_RESERVE_BYTES = 400 * 1024 * 1024

CPU_TEMP_CHIPS = ("coretemp", "k10temp", "zenpower", "cpu_thermal", "cpu-thermal", "acpitz")
CPU_TEMP_LABELS = ("package id 0", "tctl", "tdie", "cpu", "package")


def _read(path: str) -> str | None:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            return handle.read().strip()
    except OSError:
        return None


def _num(value: str | None) -> float | None:
    try:
        return float(value) if value not in (None, "") else None
    except ValueError:
        return None


def _run(args: list[str], timeout: float = 1.5) -> str | None:
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError):
        return None
    return result.stdout if result.returncode == 0 else None


def _cpu_times() -> tuple[int, int] | None:
    first = (_read("/proc/stat") or "").split("\n", 1)[0].split()
    if len(first) < 5 or first[0] != "cpu":
        return None
    values = [int(item) for item in first[1:] if item.isdigit()]
    idle = values[3] + (values[4] if len(values) > 4 else 0)
    return sum(values), idle


def cpu_usage_percent(interval: float = 0.25) -> float | None:
    start = _cpu_times()
    if not start:
        return None
    time.sleep(interval)
    end = _cpu_times()
    if not end or end[0] <= start[0]:
        return None
    return round(max(0.0, min(100.0, (1 - (end[1] - start[1]) / (end[0] - start[0])) * 100)), 1)


def cpu_topology() -> dict[str, Any]:
    """Physical cores vs logical threads, like the Windows Task Manager."""
    name = None
    cores: set[tuple[str, str]] = set()
    threads = 0
    physical_id = "0"
    for line in (_read("/proc/cpuinfo") or "").splitlines():
        key, _, value = line.partition(":")
        key, value = key.strip(), value.strip()
        if key == "model name" and not name:
            name = value
        elif key == "processor":
            threads += 1
        elif key == "physical id":
            physical_id = value
        elif key == "core id":
            cores.add((physical_id, value))
    if not threads:
        threads = os.cpu_count() or 0
    physical = len(cores) or None
    if physical is None:
        output = _run(["lscpu", "-p=CORE,SOCKET"])
        if output:
            pairs = {tuple(row.split(",")[:2]) for row in output.splitlines() if row and not row.startswith("#")}
            physical = len(pairs) or None
    return {"name": name, "physicalCores": physical, "logicalThreads": threads or None}


def cpu_speed_mhz() -> dict[str, float | None]:
    values = []
    for path in glob.glob("/sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq"):
        number = _num(_read(path))
        if number:
            values.append(number / 1000)
    if not values:
        for line in (_read("/proc/cpuinfo") or "").splitlines():
            if line.lower().startswith("cpu mhz"):
                number = _num(line.split(":", 1)[1])
                if number:
                    values.append(number)
    maximum = _num(_read("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq"))
    return {
        "currentMHz": round(sum(values) / len(values)) if values else None,
        "maxMHz": round(maximum / 1000) if maximum else None,
    }


def _hwmon_temps() -> list[tuple[str, str, float]]:
    found = []
    for hw in sorted(glob.glob("/sys/class/hwmon/hwmon*")):
        chip = (_read(os.path.join(hw, "name")) or os.path.basename(hw)).lower()
        for path in sorted(glob.glob(os.path.join(hw, "temp*_input"))):
            value = _num(_read(path))
            if value is None:
                continue
            label = (_read(path.replace("_input", "_label")) or os.path.basename(path)).lower()
            found.append((chip, label, value / 1000))
    return found


def cpu_temperature_c() -> float | None:
    temps = _hwmon_temps()
    for chip in CPU_TEMP_CHIPS:
        chip_temps = [item for item in temps if item[0] == chip]
        if not chip_temps:
            continue
        for wanted in CPU_TEMP_LABELS:
            for _, label, value in chip_temps:
                if wanted in label:
                    return round(value, 1)
        return round(max(value for _, _, value in chip_temps), 1)
    output = _run(["sensors", "-j"]) if shutil.which("sensors") else None
    if output:
        try:
            data = json.loads(output)
        except ValueError:
            data = {}
        for chip_name, chip in data.items():
            if not any(token in chip_name.lower() for token in CPU_TEMP_CHIPS):
                continue
            for feature in chip.values():
                if isinstance(feature, dict):
                    for key, value in feature.items():
                        if key.endswith("_input") and key.startswith("temp") and isinstance(value, (int, float)):
                            return round(float(value), 1)
    return None


def memory() -> dict[str, Any]:
    info: dict[str, int] = {}
    for line in (_read("/proc/meminfo") or "").splitlines():
        key, _, rest = line.partition(":")
        parts = rest.split()
        if parts and parts[0].isdigit():
            info[key] = int(parts[0]) * 1024
    total = info.get("MemTotal")
    available = info.get("MemAvailable", info.get("MemFree"))
    if not total or available is None:
        return {"usedBytes": None, "totalBytes": total, "percent": None}
    used = total - available
    return {"usedBytes": used, "totalBytes": total, "percent": round(used / total * 100, 1)}


def _pci_name(slot: str | None) -> str | None:
    if not slot or not shutil.which("lspci"):
        return None
    output = _run(["lspci", "-mm", "-s", slot])
    if not output:
        return None
    parts = [part for part in output.replace('"', "\x00").split("\x00") if part.strip() and part.strip() != " "]
    # lspci -mm: slot, class, vendor, device, ...
    return " ".join(parts[2:4]).strip() or None if len(parts) >= 4 else None


def _nvidia_gpus() -> list[dict[str, Any]]:
    if not shutil.which("nvidia-smi"):
        return []
    query = "name,temperature.gpu,utilization.gpu,clocks.gr,memory.used,memory.total"
    output = _run(["nvidia-smi", f"--query-gpu={query}", "--format=csv,noheader,nounits"])
    gpus = []
    for line in (output or "").splitlines():
        cells = [cell.strip() for cell in line.split(",")]
        if len(cells) < 6:
            continue
        mib = 1024 * 1024
        used, total = _num(cells[4]), _num(cells[5])
        gpus.append({
            "name": cells[0], "vendor": "nvidia", "tempC": _num(cells[1]), "usagePercent": _num(cells[2]),
            "speedMHz": _num(cells[3]),
            "vramUsedBytes": int(used * mib) if used is not None else None,
            "vramTotalBytes": max(0, int(total * mib) - HOST_VRAM_RESERVE_BYTES) if total is not None else None,
        })
    return gpus


def _drm_gpus() -> list[dict[str, Any]]:
    gpus = []
    for card in sorted(glob.glob("/sys/class/drm/card[0-9]")):
        device = os.path.join(card, "device")
        vendor = (_read(os.path.join(device, "vendor")) or "").lower()
        if vendor not in ("0x1002", "0x8086"):  # AMD, Intel (NVIDIA handled by nvidia-smi)
            continue
        slot = None
        for line in (_read(os.path.join(device, "uevent")) or "").splitlines():
            if line.startswith("PCI_SLOT_NAME="):
                slot = line.split("=", 1)[1]
        temp = None
        for path in glob.glob(os.path.join(device, "hwmon", "hwmon*", "temp1_input")):
            value = _num(_read(path))
            if value is not None:
                temp = round(value / 1000, 1)
                break
        speed = None
        for path in glob.glob(os.path.join(device, "hwmon", "hwmon*", "freq1_input")):
            value = _num(_read(path))
            if value:
                speed = round(value / 1e6)
        if speed is None:
            for line in (_read(os.path.join(device, "pp_dpm_sclk")) or "").splitlines():
                if line.rstrip().endswith("*"):
                    digits = "".join(ch for ch in line.split(":", 1)[-1].split("M")[0] if ch.isdigit())
                    speed = float(digits) if digits else None
        if speed is None:
            for path in (os.path.join(card, "gt_cur_freq_mhz"), os.path.join(device, "gt", "gt0", "rps_cur_freq_mhz")):
                value = _num(_read(path))
                if value:
                    speed = value
                    break
        used = _num(_read(os.path.join(device, "mem_info_vram_used")))
        total = _num(_read(os.path.join(device, "mem_info_vram_total")))
        gpus.append({
            "name": _pci_name(slot) or ("AMD GPU" if vendor == "0x1002" else "Intel GPU"),
            "vendor": "amd" if vendor == "0x1002" else "intel",
            "tempC": temp, "usagePercent": _num(_read(os.path.join(device, "gpu_busy_percent"))),
            "speedMHz": speed,
            "vramUsedBytes": int(used) if used is not None else None,
            "vramTotalBytes": max(0, int(total) - HOST_VRAM_RESERVE_BYTES) if total else None,
        })
    return gpus


def hints(cpu_temp: float | None, gpus: list[dict[str, Any]]) -> list[str]:
    notes = []
    if cpu_temp is None:
        notes.append("CPU temperature is not exposed by this system. Install lm-sensors (the launcher can do this for your distro) and run sensors-detect.")
    if not gpus:
        notes.append("No GPU sensors found. NVIDIA needs the driver utilities (nvidia-smi); AMD/Intel are read from sysfs.")
    return notes


def collect(sample_interval: float = 0.25) -> dict[str, Any]:
    topology = cpu_topology()
    speed = cpu_speed_mhz()
    temp = cpu_temperature_c()
    gpus = _nvidia_gpus() + _drm_gpus()
    return {
        "sampledAt": datetime.now(timezone.utc).isoformat(),
        "hostname": os.uname().nodename if hasattr(os, "uname") else None,
        "cpu": {
            "name": topology["name"], "tempC": temp, "usagePercent": cpu_usage_percent(sample_interval),
            "speedMHz": speed["currentMHz"], "maxSpeedMHz": speed["maxMHz"],
            "physicalCores": topology["physicalCores"], "logicalThreads": topology["logicalThreads"],
        },
        "memory": memory(),
        "gpus": gpus,
        "tools": {name: bool(shutil.which(name)) for name in ("sensors", "nvidia-smi", "lspci")},
        "hints": hints(temp, gpus),
    }


if __name__ == "__main__":
    print(json.dumps(collect(), indent=2))
