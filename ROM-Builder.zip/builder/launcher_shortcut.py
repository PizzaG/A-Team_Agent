#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

#
# IMPORTS
#
import os
from pathlib import Path
from builder.icon_manager import (
    get_selected_icon_path
)

#
# CREATE DESKTOP LAUNCHER SHORTCUT
#
def create_desktop_launcher():
    #
    # A-Team Android ROM Builder location.
    #
    builder_path = (
        Path(__file__)
        .resolve()
        .parent
        .parent
    )
    #
    # Main GUI entry point.
    #
    gui_path = (
        builder_path / "gui.py"
    )
    #
    # Currently selected launcher icon.
    #
    icon_path = (
        get_selected_icon_path()
    )
    #
    # User Desktop location.
    #
    desktop_path = (
        Path.home() / "Desktop"
    )
    #
    # Create Desktop directory if it does not exist.
    #
    desktop_path.mkdir(
        parents=True,
        exist_ok=True
    )
    #
    # Launcher filename.
    #
    launcher_path = (
        desktop_path
        / "A-Team Android ROM Builder.desktop"
    )
    #
    # Desktop launcher contents.
    #
    launcher = f"""[Desktop Entry]
Type=Application
Name=A-Team Android ROM Builder
Comment=A-Team Android ROM Builder
Exec=python3 "{gui_path}"
Path={builder_path}
Icon={icon_path}
Terminal=run
Categories=Development;Utility;
"""
    #
    # Write launcher.
    #
    launcher_path.write_text(
        launcher,
        encoding="utf-8"
    )
    #
    # Make executable.
    #
    launcher_path.chmod(
        launcher_path.stat().st_mode
        | 0o111
    )
    #
    # Return launcher path to the caller.
    #
    return launcher_path
