#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

#
# DEFINE PROJECT SUMMARY
#
def build_project_summary(project):
    text = []
    env = project.as_environment()
    #
    # PROJECT PROFILE
    #
    if project.profile_name:
        profile_status = (
            " (Modified)"
            if project.profile_modified
            else ""
        )
        text.append(
            f"Project Profile: "
            f"{project.profile_name}"
            f"{profile_status}"
        )
    else:

        text.append(
            "Project Profile: Unsaved"
        )
    #
    # BUILD HOST
    #
    text.append(
        f"Build Host: "
        f"{project.host_name or 'Local'}"
    )

    text.append("")

    text.append(
        f"A-Team Addon Location: "
        f"{project.setup_vars.get('A_TEAM_SETUP_LOCATION', 'Unknown')}"
    )
    text.append(
        ""
    )
    text.append(
        f"Device: "
        f"{project.device_vars.get('DEVICE_DISPLAY_NAME', 'Unknown')}"
    )
    text.append(
        f"Device Chipset: "
        f"{project.device_vars.get('DEVICE_SOC', 'Unknown')}"
    )
    text.append(
        f"Device Codename: "
        f"{project.device_vars.get('DEVICE_DISPLAY_CODENAME', 'Unknown')}"
    )
    text.append(
        f"Device Kernel Version: "
        f"{project.device_vars.get('DEVICE_KERNEL', 'Unknown')}"
    )
    text.append(
        f"Device Model Number: "
        f"{project.device_vars.get('DEVICE_MODEL_NUMBER', 'Unknown')}"
    )
    text.append(
        ""
    )
    text.append(
        f"ROM: "
        f"{project.rom_vars.get('ROM_DISPLAY_NAME', 'Unknown')}"
    )
    text.append(
        f"ROM Android Version: {project.android_version}"
    )
    text.append(
        f"ROM Branch: {project.rom_branch}"
    )
    text.append(
        f"ROM Config Path: {project.rom_config_path}"
    )
    text.append(
        f"ROM Source Path: {project.rom_path}"
    )
    text.append(
        ""
    )
    text.append(
        f"Build Variant: {project.build_variant.capitalize()}"
    )
    text.append(
        f"Clean Variant: "
        f"{project.clean_variant.capitalize()}"
    )
    text.append(
        f"Gapps Variant: "
        f"{project.gapps_variant.capitalize()}"
    )
    installer_name = (
        "Custom A-Team Installer"
        if project.installer_variant.lower() == "custom"
        else "Default ROM Installer"
    )
    text.append(
        f"Installer Variant: {installer_name}"
    )
    text.append(
        ""
    )
    text.append(
        f"Build Jobs: "
        f"{project.build_jobs}"
    )
    text.append(
        f"Ccache: "
        f"{project.use_ccache}"
    )
    text.append(
        f"Custom APN: "
        f"{project.custom_apn}"
    )
    # DEBUG
    #print(project.device_vars)
    #print(project.rom_vars)
    #print(project.build_variant)
    return "\n".join(text)
