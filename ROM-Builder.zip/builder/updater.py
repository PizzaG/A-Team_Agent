#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

import json
from urllib.request import Request, urlopen
from builder.version import VERSION

VERSION_URL = (
    "https://ateam.gotadell.com/git/PizzaG/"
    "A-Team-Android_ROM_Builder/raw/branch/releases/Updates/version.json"
)

def check_for_update():
    try:
        req = Request(
            VERSION_URL,
            headers={
                "User-Agent": "A-Team-Android-ROM-Builder-Updater/1.0"
            }
        )
        with urlopen(req) as response:
            info = json.load(response)
        if int(info["version"]) > VERSION:
            return info
    except Exception as e:
        print(f"Update Check Failed: {e}")
    return None
