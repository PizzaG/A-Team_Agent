#
# Copyright (C) 2019-Present A-Team Digital Solutions
#
"""
Device Manager

Discovers available device configs.
"""

from pathlib import Path
from .config_loader import load_config

ROOT = Path(
    __file__
).resolve().parent.parent
CONFIG_DIR = ROOT / "configs" / "devices"

def get_devices():
    devices = []
    for file in CONFIG_DIR.glob("*.conf"):
        if file.stem.lower() in [
            "rom",
            "hosts",
            "splash",
            "upload_services"
        ]:
            continue
        config = load_config(file)
        devices.append({
            "name": file.stem.lower(),
            "display": config.get(
                "DEVICE_DISPLAY_NAME",
                file.stem.capitalize()
            )
        })
    return sorted(
        devices,
        key=lambda d: d["display"]
    )
