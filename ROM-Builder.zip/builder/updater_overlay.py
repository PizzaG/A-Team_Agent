#!/usr/bin/env python3
#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

from gi.repository import Gtk, GLib

class UpdaterOverlay(Gtk.EventBox):
    def __init__(self):
        super().__init__()
        self.set_hexpand(True)
        self.set_vexpand(True)
        self.set_visible_window(True)
        self.set_above_child(True)
        self.set_no_show_all(True)
        self._pulse_id = None
        self._determinate = False
        #
        # Centered content
        #
        outer = Gtk.EventBox()
        outer.set_visible_window(True)
        background = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL
        )
        background.set_hexpand(True)
        background.set_vexpand(True)
        background.set_halign(Gtk.Align.FILL)
        background.set_valign(Gtk.Align.FILL)
        outer.add(background)
        outer.set_halign(Gtk.Align.FILL)
        outer.set_valign(Gtk.Align.FILL)
        frame = Gtk.Frame()
        frame.set_size_request(500, -1)
        frame.set_shadow_type(Gtk.ShadowType.OUT)
        content = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=15
        )
        content.set_border_width(25)
        title = Gtk.Label()
        title.set_markup(
            "<span size='large' foreground='#00FFFF' weight='bold'>"
            "A-Team Android ROM Builder -- Updater"
            "</span>"
        )
        self.status = Gtk.Label()
        self.status.set_markup(
            '<span foreground="#00FFFF" weight="bold">'
            'Preparing Update ...'
            '</span>'
        )
        self.status.set_xalign(0)
        self.status.set_line_wrap(True)
        self.status.set_max_width_chars(50)
        self.progress = Gtk.ProgressBar()
        self.progress.set_show_text(False)
        info = Gtk.Label()
        info.set_markup(
            '<span foreground="#00FFFF" weight="bold">'
            "Please Don't Close The Application While Updating"
            '</span>'
        )
        content.pack_start(title, False, False, 0)
        content.pack_start(self.status, False, False, 0)
        content.pack_start(self.progress, False, False, 0)
        content.pack_start(info, False, False, 0)
        frame.add(content)
        alignment = Gtk.Alignment.new(
            0.5,
            0.5,
            0,
            0
        )
        alignment.add(frame)
        background.pack_start(
            alignment,
            True,
            True,
            0
        )
        outer.set_name("update-overlay")
        self.add(outer)
        #
        # Hidden until needed
        #
        self.hide()
    def show_overlay(self):
        self.set_no_show_all(False)
        self.show_all()
    def hide_overlay(self):
        self.stop()
        self.hide()
        self.set_no_show_all(True)
    def set_status(self, text):
        # Escape status text before applying Pango markup so shell/update
        # messages cannot accidentally be interpreted as markup.
        escaped = GLib.markup_escape_text(str(text))
        self.status.set_markup(
            f'<span foreground="#00FFFF" weight="bold">{escaped}</span>'
        )

    def set_progress(self, current, total):
        if total <= 0:
            return
        if self._pulse_id is not None:
            GLib.source_remove(self._pulse_id)
            self._pulse_id = None
        self._determinate = True
        fraction = max(
            0.0,
            min(1.0, float(current) / float(total))
        )
        self.progress.set_fraction(fraction)

    def start(self):
        self._determinate = False
        self.progress.set_fraction(0.0)
        if self._pulse_id is None:
            self._pulse_id = GLib.timeout_add(
                80,
                self._pulse
            )
    def stop(self):
        if self._pulse_id is not None:
            GLib.source_remove(self._pulse_id)
            self._pulse_id = None
        self._determinate = False
        self.progress.set_fraction(1.0)
    def _pulse(self):
        self.progress.pulse()
        return True
