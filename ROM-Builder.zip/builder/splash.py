#!/usr/bin/env python3
#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk
from builder.splash_manager import (
    get_selected_splash_path,
)

class Splash(Gtk.Window):
    def __init__(self):
        super().__init__()
        self.set_default_size(700, 500)
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_keep_above(True)
        box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=15
        )
        box.set_margin_top(20)
        box.set_margin_bottom(20)
        box.set_margin_start(20)
        box.set_margin_end(20)
        image = Gtk.Image.new_from_file(
            str(get_selected_splash_path())
        )
        image.set_halign(Gtk.Align.CENTER)
        self.status = Gtk.Label()
        self.status.set_markup(
            '<span foreground="cyan" size="12000">'
            '</span>'
        )
        self.status.set_halign(Gtk.Align.CENTER)
        box.pack_start(
            image,
            False,
            False,
            0
        )
        box.pack_start(
            self.status,
            False,
            False,
            0
        )
        self.add(box)
    def set_status(self, text):
        self.status.set_markup(
            f'<span foreground="cyan" size="12000">{text}</span>'
        )
        while Gtk.events_pending():
            Gtk.main_iteration()
