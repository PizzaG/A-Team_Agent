#
# Copyright (C) 2019-Present A-Team Digital Solutions
#
"""
Project Profile Manager

Handles saving and loading reusable
A-Team Android ROM Builder project profiles.
"""

import json
from pathlib import Path
from .project import Project

ROOT = Path(__file__).resolve().parent.parent
PROFILES_DIR = ROOT / "profiles"

def ensure_profiles_dir():
    PROFILES_DIR.mkdir(
        parents=True,
        exist_ok=True
    )
def get_profiles():
    """
    Return all valid project profiles.
    """
    if not PROFILES_DIR.exists():
        return []
    profiles = []
    for path in sorted(
        PROFILES_DIR.glob("*.json")
    ):
        try:
            with open(
                path,
                "r",
                encoding="utf-8"
            ) as f:
                data = json.load(f)
            profiles.append({
                "name": data.get(
                    "profile_name",
                    path.stem
                ),
                "path": path
            })
        except (
            OSError,
            json.JSONDecodeError
        ):
            #
            # Ignore invalid profile files.
            #
            continue
    return profiles
def project_to_dict(project):
    """
    Convert Project into profile data.
    """
    return {
        "profile_name":
            project.profile_name,
        "host_name":
            project.host_name,
        "device_name":
            project.device_name,
        "rom_path":
            project.rom_path,
        "android_version":
            project.android_version,
        "build_variant":
            project.build_variant,
        "build_command":
            project.build_command,
        "gapps_variant":
            project.gapps_variant,
        "clean_variant":
            project.clean_variant,
        "installer_variant":
            project.installer_variant,
        "build_jobs":
            project.build_jobs,
        "use_ccache":
            project.use_ccache,
        "custom_apn":
            project.custom_apn
    }
def save_profile(
    project,
    filename
):
    """
    Save a Project profile.
    """
    ensure_profiles_dir()
    filename = Path(filename)
    with open(
        filename,
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            project_to_dict(project),
            f,
            indent=4
        )
def load_profile(filename):
    """
    Load a Project profile.
    """
    with open(
        filename,
        "r",
        encoding="utf-8"
    ) as f:

        data = json.load(f)
    project = Project()
    project.profile_name = data.get(
        "profile_name",
        Path(filename).stem
    )
    project.host_name = data.get(
        "host_name",
        "Local"
    )
    project.device_name = data.get(
        "device_name",
        ""
    )
    project.set_rom_path(
        data.get(
            "rom_path",
            ""
        )
    )
    project.android_version = data.get(
        "android_version",
        "16"
    )
    project.build_variant = data.get(
        "build_variant",
        "userdebug"
    )
    project.build_command = data.get(
        "build_command",
        ""
    )
    project.gapps_variant = data.get(
        "gapps_variant",
        "vanilla"
    )
    project.clean_variant = data.get(
        "clean_variant",
        "full"
    )
    project.installer_variant = data.get(
        "installer_variant",
        "custom"
    )
    project.build_jobs = int(
        data.get(
            "build_jobs",
            6
        )
    )
    project.use_ccache = bool(
        data.get(
            "use_ccache",
            True
        )
    )
    project.custom_apn = bool(
        data.get(
            "custom_apn",
            False
        )
    )
    return project
