#!/usr/bin/env python3
#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
IMAGE_DIR = BASE / "images"
CONFIG = BASE / "configs" / "splash.conf"
DEFAULT_SPLASH = "splash-new-green-black-blue.png"

def get_available_splashes():
    """
    Return every splash image found inside images/.
    """
    splashes = []
    for image in sorted(IMAGE_DIR.glob("*")):
        if (
            image.is_file()
            and image.suffix.lower() == ".png"
            and "splash" in image.stem.lower()
        ):
            splashes.append(image.name)
    return splashes
def filename_to_display(filename):
    """
    splash-purple.png -> Purple
    splash-dark-red.png -> Dark Red
    """
    name = Path(filename).stem
    name = name.replace("splash", "")
    name = name.replace("-", " ")
    name = name.replace("_", " ")
    name = name.strip()
    if not name:
        return "Default"
    return name.title()
def load_selected_splash():
    """
    Read configs/splash.conf
    """
    if not CONFIG.exists():
        return DEFAULT_SPLASH
    for line in CONFIG.read_text().splitlines():
        line = line.strip()
        if not line.startswith("SPLASH="):
            continue
        splash = line.split("=", 1)[1].strip()
        if (IMAGE_DIR / splash).exists():
            return splash
        break
    return DEFAULT_SPLASH
def save_selected_splash(filename):
    """
    Save selected splash.
    """
    CONFIG.write_text(
        f"SPLASH={filename}\n"
    )
def get_selected_splash_path():
    """
    Full path to the currently selected splash.
    """
    return IMAGE_DIR / load_selected_splash()
def get_display_names():
    """
    Returns a list of friendly names.
    Example:
        ["Blue", "Green", "Purple"]
    """
    return [
        filename_to_display(name)
        for name in get_available_splashes()
    ]
def display_to_filename(display):
    """
    Converts a friendly name back into the filename.
    Example:
        Purple -> splash-purple.png
    """
    for filename in get_available_splashes():
        if filename_to_display(filename) == display:
            return filename
    return DEFAULT_SPLASH
