#
# Copyright (C) 2019-Present A-Team Digital Solutions
#
"""
Project Loader

Creates and populates a Project object.
"""

from pathlib import Path
from .project import Project
from .config_loader import load_config


def _load_remote_rom_config(rom_path, remote_cfg):
    """Load rom.conf directly from the selected SSH build host."""
    import subprocess
    from .hosts_manager import build_ssh_args

    remote_config = f"{rom_path.rstrip('/')}/rom.conf"
    ssh_args = build_ssh_args(remote_cfg)

    result = subprocess.run(
        ssh_args + ["cat", remote_config],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        return None, remote_config, result.stderr.strip()

    data = {}
    for line in result.stdout.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip()
        if ((value.startswith('"') and value.endswith('"')) or
                (value.startswith("'") and value.endswith("'"))):
            value = value[1:-1]
        # Keep remote paths remote. Convert ~/... to $HOME/... so the
        # generated shell command expands it on the SSH machine rather
        # than on the GUI machine.
        if value == "~":
            value = "$HOME"
        elif value.startswith("~/"):
            value = "$HOME/" + value[2:]
        data[key.strip()] = value

    return data, remote_config, ""

def load_project(
    rom_path,
    device_name,
    remote_cfg=None
):
    project = Project()
    project.set_rom_path(
        rom_path
    )
    project.set_device(
        device_name
    )
    #
    # Device Configuration
    #
    project.device_vars = load_config(
        f"configs/devices/{device_name.lower()}.conf"
    )
    #
    # ROM Configuration
    #
    # If the selected ROM root contains its own rom.conf,
    # use that instead of the builder's default rom.conf.
    #
    local_rom_config = (
        Path(rom_path) / "rom.conf"
    )

    # For SSH builds, rom_path belongs to the remote machine. The local
    # GUI cannot use Path.exists() against it, so query the remote host
    # directly and load the remote rom.conf when it exists.
    if remote_cfg:
        remote_vars, remote_config, remote_error = _load_remote_rom_config(
            rom_path,
            remote_cfg
        )
        if remote_vars is not None:
            print()
            print("================================")
            print("Using Remote ROM Configuration")
            print("================================")
            print()
            print(f"ROM Config: {remote_config}")
            print()
            project.rom_vars = remote_vars
            project.rom_config_path = remote_config
        else:
            print()
            print("================================")
            print("Remote ROM Configuration Not Found")
            print("================================")
            print()
            print(f"Remote ROM Config: {remote_config}")
            if remote_error:
                print(f"SSH Error: {remote_error}")
            print("Falling back to builder configs/rom.conf")
            print()
            project.rom_vars = load_config(
                "configs/rom.conf"
            )
            project.rom_config_path = (
                "configs/rom.conf"
            )
    elif local_rom_config.is_file():
        print()
        print("================================")
        print("Using ROM Local Configuration")
        print("================================")
        print()
        print(f"ROM Config: {local_rom_config}")
        print()
        project.rom_vars = load_config(
            local_rom_config
        )
        project.rom_config_path = str(
            local_rom_config
        )
    else:
        print()
        print("================================")
        print("Using Builder ROM Configuration")
        print("================================")
        print()
        print("ROM Config: configs/rom.conf")
        print()
        project.rom_vars = load_config(
            "configs/rom.conf"
        )
        project.rom_config_path = (
            "configs/rom.conf"
        )
    #
    # Upload Services Configuration
    #
    project.upload_vars = load_config(
        "configs/upload_services.conf"
    )
    #
    # A-Team Setup Configuration
    #
    project.setup_vars = load_config(
        "configs/a_team_setup.conf"
    )
    return project
