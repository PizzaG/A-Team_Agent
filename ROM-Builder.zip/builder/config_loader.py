#
# Copyright (C) 2019-Present A-Team Digital Solutions
#
"""
Configuration Loader

Reads simple KEY=VALUE config files.
"""

from pathlib import Path

def load_config(filename, expand_user=True):
    data = {}
    path = Path(filename)
    if not path.exists():
        print(f"Config Not Found: {filename}")
        return data
    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            #
            # Skip comments
            #
            if not line:
                continue
            if line.startswith("#"):
                continue
            #
            # Must contain =
            #
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            value = value.strip()
            # Remove surrounding quotes
            if (
                (value.startswith('"') and value.endswith('"'))
                or
                (value.startswith("'") and value.endswith("'"))
            ):
                value = value[1:-1]
            #
            # Expand ~ to the current machine's home directory when
            # requested. Remote configs must disable this so paths are
            # not accidentally expanded using the GUI machine's HOME.
            #
            if expand_user:
                value = str(Path(value).expanduser())
            data[key.strip()] = value
    return data
