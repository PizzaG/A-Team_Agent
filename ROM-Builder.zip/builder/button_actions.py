#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

from .actions import (
    build_command,
    sync_command,
    gapps_sync_command,
)
from .project_loader import load_project
from builder.actions import clean_command

class ButtonActions:
    def __init__(self, terminal, notebook):
        self.terminal = terminal
        self.notebook = notebook
    def load_project(self, rom_path, device, remote_cfg=None):
        if not rom_path:
            return None
        if not device:
            return None
        return load_project(
            rom_path,
            device,
            remote_cfg=remote_cfg
        )
    def sync(self, project):
        if not project:
            return
        cmd = sync_command(project)
        self.notebook.set_current_page(4)
        self.terminal.run_project(project, cmd)
    def gapps_sync(self, project):
        if not project:
            return
        cmd = gapps_sync_command(
            project
        )
        self.notebook.set_current_page(4)
        self.terminal.run_project(project, cmd)
    def build(
        self,
        project,
        android_version,
        build_jobs,
        use_ccache
    ):
        if not project:
            return
        cmd = build_command(
            project,
            android_version,
            build_jobs,
            use_ccache
        )
        self.notebook.set_current_page(4)
        self.terminal.run_project(project, cmd)
    def clean(self, project):
        if not project:
            return

        # Mark this invocation as a user-requested clean.  clean_command()
        # builds the subprocess environment from project.as_environment(),
        # so setting os.environ in gui.py alone does not reach clean.sh.
        project.setup_vars["USER_CLEAN"] = "true"
        try:
            cmd = clean_command(project)
        finally:
            # Do not leave USER_CLEAN set on the Project, otherwise a later
            # normal build could incorrectly enter the user-clean path.
            project.setup_vars.pop("USER_CLEAN", None)

        self.notebook.set_current_page(4)
        self.terminal.run_project(project, cmd)
