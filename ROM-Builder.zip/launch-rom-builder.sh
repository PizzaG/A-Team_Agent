#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required to launch ROM Builder." >&2
  exit 1
fi
if ! python3 -c 'import gi; gi.require_version("Gtk", "3.0"); gi.require_version("Vte", "2.91"); from gi.repository import Gtk, Vte' >/dev/null 2>&1; then
  echo "GTK 3 and PyGObject with VTE bindings are required. Install python3-gi, gir1.2-gtk-3.0, gir1.2-vte-2.91." >&2
  exit 1
fi
exec python3 gui.py
