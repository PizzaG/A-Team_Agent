---
name: rom-builder-control
description: >-
  REQUIRED activation for explicit ROM Builder requests. Trigger immediately when
  the user says "ROM-Builder", "ROM Builder", "rom builder", "build a rom", or asks
  to configure, build, sync, clean, or otherwise operate an Android ROM source tree.
  This skill controls the installed A-Team ROM Builder module through its shared
  configuration, CLI, job API, and interactive Build Console. Do not just explain
  how to perform the task; inspect state and operate the module when requested.
---

# ROM Builder Control

Use this skill only while the ROM Builder module is installed. If it is not listed
in available skills or its module directory is absent, tell the user to install it.

## Mandatory activation and first steps

1. For the trigger phrases in the description, read and follow this skill before
   responding or taking action. Do not treat the trigger phrase as casual context.
2. Inspect the ROM Builder module's current status and shared form state before
   changing anything. The visible UI and Agent CLI operate on the same configuration.
3. Use the module's bundled CLI/help to discover supported commands; do not invent
   command names or bypass its validation.
4. Use the configured Android source directory as the working directory. The
   interactive Build Console shell remains at the source root after task completion.
5. Before destructive clean operations, summarize the selected clean variant and
   obtain confirmation if the operation could delete source/build outputs.
6. Track build job IDs separately from interactive shell session IDs. Poll the job
   API for task status/logs; use the terminal API only for interactive shell input.
7. Report completion from the actual job status and exit code, not from command
   submission alone. Preserve logs and actionable error output.

## UI and shared configuration

The shared form includes: Android source directory, Device, Android version,
Build variant, GApps variant, Installer variant, Build jobs, Custom APN, Use ccache,
Clean variant, and Known ROM build command. Read or update these through the
module's supported CLI/API so the UI remains synchronized.

The available actions include Build ROM, Sync source, Sync GApps, Clean, A-Team
setup, and Upload build. Confirm required settings and source path before starting.

## Interactive terminal

After Load Configuration, use the persistent terminal session rooted at the Android
source directory. The terminal is not the build-job process. Do not change its cwd
unless the user explicitly asks. After a Build ROM job completes, the shell is
already at the source root; do not add an artificial "Press ENTER to Exit" step.
For other completed tasks, retain the terminal's normal completion prompt behavior.

## Operational discipline

- Never claim a build succeeded unless the job reports success and exit code 0.
- If a command fails, inspect its log and relevant state before retrying.
- Do not start duplicate jobs when an existing job is active.
- Keep the user's selected device, ROM path, variants, jobs, APN, ccache, and build
  command intact unless the user asks to change them.
