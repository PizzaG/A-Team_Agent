---
name: rom-builder-control
description: >-
  Trigger when the user says ROM-Builder, rom builder, or build a rom, or asks
  the Agent to use, configure, run, inspect, troubleshoot, or control ROM Builder.
  Treat these phrases as explicit ROM Builder intent. Load this skill to operate
  the complete UI, CLI, scripts, configuration, task state, interactive terminal,
  logs, prompts, and hardware resource monitor. Covers build, sync, GApps sync,
  setup, upload, clean, cancellation, and CPU, GPU, RAM, and VRAM readings.
license: Proprietary
metadata:
  author: A-Team Agent
  module: ROM-Builder
  module-version: "1.4"
---
# ROM Builder control

This skill is installed and enabled only while the ROM Builder module is installed. The module's UI, Agent and CLI are one control surface. Treat ROM Builder intent as explicit when one of the trigger phrases appears: the user may want to operate the UI manually, ask the Agent to operate it, or ask for an explanation/troubleshooting.

## Start every ROM Builder task by inspecting the live system

Run commands from the A-Team Agent project root:

```bash
python3 -S modules/ROM-Builder/agent_cli.py spec
python3 -S modules/ROM-Builder/agent_cli.py snapshot
```

The CLI is authoritative. Do not invent controls, commands, paths, or state. Read `spec` for controls, allowed values, button actions, terminal semantics and outputs. Read `snapshot` before acting and after every action. The CLI emits JSON.

## Configuration controls

- Read: `form-get`
- Change: `form-set --payload '{"device":"<codename>","rom_path":"/absolute/source/path","build_jobs":8,"use_ccache":true}'`
- Fields: `rom_path`, `device`, `android_version`, `build_command`, `build_variant`, `gapps_variant`, `clean_variant`, `installer_variant`, `build_jobs`, `use_ccache`, `custom_apn`.
- `load-config` is the UI's Load Configuration action; `config`, `devices`, `hosts`, and `commands` inspect configuration.
- Browse is a human-operated native folder picker. The Agent sets `rom_path` directly.
- Keep the loaded Android source directory as the working directory for interactive terminal work.

## Actions

Use `run --action build|sync|gapps-sync|setup|upload|clean [--payload '<JSON>'] [--wait SECONDS]`. The saved form is used unless an optional payload overrides it for this run. Only one ROM Builder task may run at a time.

**Destructive action:** `clean` can delete build outputs. Explain the selected clean variant and obtain explicit user confirmation immediately before starting it. Never infer consent from the trigger phrase alone.

## Job state and output

- `list` lists persisted jobs and the active job.
- `status --job-id <uuid>` reads task state.
- `logs --job-id <uuid> --clean` reads plain-text output; use `--offset <next_offset>` for incremental polling.
- `cancel --job-id <uuid>` stops a running task. Only cancel when asked.
- Shell-session IDs and build-job IDs are different types. Never poll a shell session with `status`/`logs`, and never treat a shell session as a running build job.
- Summarize observed status, exit code, recent output and concrete error lines. Do not claim success unless the CLI reports `succeeded`.

## Build Console interactive shell

After Load Configuration, the UI starts a persistent interactive Bash shell in the selected ROM source directory:
- `shell-start --cwd <rom_path>`
- `shell-poll --session-id <id> --offset <bytes>`
- `shell-input --session-id <id> --text <bytes>`
- `shell-stop --session-id <id>`

Use `shell-input` for the persistent shell. For a running build task, use `keys --job-id <id> --keys "y,Enter"` or `input --job-id <id> --text "line"`; `input --raw` sends exact bytes. Supported key names include Enter, Tab, Esc, Space, Backspace, Delete, arrows, Home/End, PageUp/PageDown and Ctrl-letter combinations. Full-screen programs such as vim/htop are not rendered faithfully in the web terminal.

When a task completes, the persistent interactive shell remains available at the loaded ROM source root. Do not insert an artificial completion prompt, blank-line gap, or synthetic exit step; the shell is already in the correct working directory.

## Resource and GPU memory policy

`sensors` reports CPU temperature/usage/speed/core/thread counts, system RAM, and per-GPU temperature/usage/speed/VRAM. `null` means unavailable; never guess.

The launcher requires a verified Ollama VRAM/model-store setup record at `backend/.deer-flow/ollama-vram-setup.json` (or the configured DeerFlow runtime home). If the record is absent or uses the older schema, the launcher runs `scripts/ollama-vram-setup.sh` and blocks Agent startup until setup succeeds. Before changing Ollama, setup inventories `OLLAMA_MODELS`, the current user's `~/.ollama/models`, every `/home/*/.ollama/models` directory (including `/home/pizzag/.ollama/models`), and common service/system locations such as `/usr/share/ollama/.ollama/models`, `/var/lib/ollama`, `/opt/ollama`, `/srv/ollama`, `/mnt`, and `/media`. It merges manifests and content-addressed blobs into one selected model store using hard links or symlinks rather than re-downloading large model layers, grants systemd's Ollama user ACL access without changing file ownership, configures `OLLAMA_MODELS`, and verifies `ollama list` still exposes the discovered model tags and configured Agent model before the Agent starts. Never infer that a model is missing merely because the API list is empty before checking these on-disk stores. Scenario 1 (`gpu_only`) configures `OLLAMA_GPU_OVERHEAD=838860800`, `LLAMA_ARG_FIT=off`, and injects `num_gpu=999` into ChatOllama profiles so all model layers are requested on GPU; an oversized model should fail instead of intentionally spilling layers to CPU/RAM. Scenario 2 (`gpu_with_cpu_spillover`) keeps the 800 MiB scheduler reserve and `LLAMA_ARG_FIT=on`, allowing Ollama to use GPU first and CPU/RAM for remaining layers. The setup configures and verifies systemd-managed Ollama services, or records that the launcher must own the daemon lifecycle. It refuses to save a local setup record for a remote Ollama URL. The reserve is Ollama scheduler accounting, not a driver-level physical lock; it cannot constrain unrelated GPU applications or a different remote model endpoint. Check Resource Monitor policy and enforcement status before making claims. Do not claim the 800 MiB is physically reserved by the GPU driver.

Use the live VRAM readings to avoid starting additional GPU-heavy Agent work when free memory is at or below the safety margin. Do not kill user processes or restart system services without explicit authorization.

## GPU identity

Prefer a marketing name from AMD sysfs/ROCm (`product_name` or `rocminfo` Marketing Name) over the generic PCI database string. If unavailable, report the PCI name and identify it as such. Never infer an exact GPU model from a device ID unless a trusted local device database resolves it.

## Working mindset

Be a careful build operator, not an optimistic button-pusher:
1. Inspect source path, device codename, Android version, build command and all variants.
2. Verify prerequisites and current task state before running anything.
3. Preserve user configuration; change only what the user asks.
4. Confirm destructive operations.
5. Use CLI state/logs as evidence; distinguish facts from diagnosis.
6. Never fabricate successful output or assume an asynchronous command completed.
