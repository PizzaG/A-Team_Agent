#!/usr/bin/env python3
"""Agent-controlled ROM Builder command runner.

This is the supported CLI boundary between the Agent UI and the existing
ROM Builder scripts. It accepts JSON requests, validates them, persists job
state/logs, and runs only allow-listed ROM Builder scripts.
"""
from __future__ import annotations

import argparse
import codecs
import fcntl
import json
import os
import re
import select
import struct
import subprocess
import sys
import termios
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
def _default_state_root() -> Path:
    # Always share state with the web UI. The CLI lives inside the project at
    # modules/ROM-Builder, so ROOT.parent.parent is the project root even when
    # the launcher marker is absent (for example, during an in-place upgrade).
    # Falling back to a per-user directory here splits UI and Agent job state.
    return ROOT.parent.parent / "logs" / "rom-builder-state"

STATE_ROOT = Path(os.environ.get("ATEAM_ROM_BUILDER_STATE") or _default_state_root()).expanduser()
CONFIG_ROOT = ROOT / "configs"
ALLOWED_ACTIONS = {
    "build": "scripts/build.sh",
    "sync": "scripts/sync.sh",
    "gapps-sync": "scripts/gapps_sync.sh",
    "clean": "scripts/clean.sh",
    "setup": "scripts/a-team_setup.sh",
    "upload": "scripts/upload.sh",
}
DEVICE_RE = re.compile(r"^[a-zA-Z0-9_-]{1,80}$")
VARIANTS = {
    "build_variant": {"user", "userdebug", "eng"},
    "gapps_variant": {"vanilla", "gapps", "micro-g", "foss"},
    "clean_variant": {"full", "lite", "none"},
    "installer_variant": {"custom", "default"},
}

def now() -> str:
    return datetime.now(timezone.utc).isoformat()

def emit(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=False))

def config_value(path: Path) -> dict[str, str]:
    data: dict[str, str] = {}
    if not path.is_file():
        return data
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip().strip('"').strip("'")
        data[key.strip()] = value
    return data

def devices() -> list[dict[str, str]]:
    results = []
    for path in sorted((CONFIG_ROOT / "devices").glob("*.conf")):
        data = config_value(path)
        results.append({
            "name": path.stem.lower(),
            "display": data.get("DEVICE_DISPLAY_NAME", path.stem.capitalize()),
            "codename": data.get("DEVICE_CODENAME", path.stem.lower()),
        })
    return sorted(results, key=lambda item: item["display"].lower())

def build_commands() -> list[dict[str, str]]:
    path = CONFIG_ROOT / "rom_build_commands.conf"
    results = []
    if not path.is_file():
        return [{"id": "", "label": "Default (rom.conf)"}]
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "-->" in line:
            label, value = [part.strip() for part in line.split("-->", 1)]
            results.append({"id": "default" if label.lower() == "default" else value.lower(), "label": line})
        else:
            results.append({"id": line.strip().lower(), "label": line.strip()})
    return results or [{"id": "", "label": "Default (rom.conf)"}]

def hosts() -> list[dict[str, str]]:
    path = CONFIG_ROOT / "hosts.conf"
    sections: list[dict[str, str]] = []
    current: dict[str, str] | None = None
    if not path.is_file():
        return [{"name": "Local", "kind": "local"}]
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith(("#", ";")):
            continue
        if line.startswith("[") and line.endswith("]"):
            if current:
                sections.append(current)
            name = line[1:-1].strip()
            current = {"name": name, "kind": "local" if name.lower() == "local" else "remote"}
        elif current and "=" in line:
            key, value = line.split("=", 1)
            current[key.strip()] = value.strip()
    if current:
        sections.append(current)
    return [h for h in sections if h["kind"] == "local" or h.get("server_address")]

def safe_rom_path(value: Any) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Choose a ROM source directory first.")
    path = Path(value).expanduser().resolve()
    if not path.is_dir():
        raise ValueError(f"ROM source directory does not exist: {path}")
    if not (path / "build").is_dir() or not (path / "device").is_dir():
        raise ValueError("The selected directory does not look like an Android source tree (expected build/ and device/).")
    if not (path / "build" / "envsetup.sh").is_file():
        raise ValueError(f"The selected source directory is missing build/envsetup.sh: {path}. Select the Android ROM checkout root, not a parent folder or output folder.")
    return path

def build_environment(payload: dict[str, Any]) -> tuple[dict[str, str], Path]:
    device = str(payload.get("device", "")).strip().lower()
    if not DEVICE_RE.fullmatch(device):
        raise ValueError("Select a valid configured device.")
    device_file = CONFIG_ROOT / "devices" / f"{device}.conf"
    if not device_file.is_file():
        raise ValueError(f"No ROM Builder device configuration exists for '{device}'.")
    rom_path = safe_rom_path(payload.get("rom_path"))
    android_version = str(payload.get("android_version", "16")).strip()
    if not re.fullmatch(r"\d{1,2}", android_version):
        raise ValueError("Android version must be a numeric version.")
    jobs = payload.get("build_jobs", 6)
    if isinstance(jobs, bool) or not isinstance(jobs, int) or not 1 <= jobs <= max(1, (os.cpu_count() or 8) * 2):
        raise ValueError("Build jobs must be a positive integer within the supported CPU limit.")
    opts: dict[str, str] = {}
    for field, allowed in VARIANTS.items():
        value = str(payload.get(field, {
            "build_variant": "userdebug",
            "gapps_variant": "vanilla",
            "clean_variant": "full",
            "installer_variant": "custom",
        }[field])).lower()
        if value not in allowed:
            raise ValueError(f"Unsupported {field.replace('_', ' ')}: {value}")
        opts[field] = value
    custom_apn = bool(payload.get("custom_apn", False))
    use_ccache = bool(payload.get("use_ccache", True))
    env = os.environ.copy()
    env.update(config_value(CONFIG_ROOT / "a_team_setup.conf"))
    env.update(config_value(device_file))
    rom_config = rom_path / "rom.conf"
    env.update(config_value(rom_config if rom_config.is_file() else CONFIG_ROOT / "rom.conf"))
    env.update({
        "DEVICE_NAME": device,
        "ROM_PATH": str(rom_path),
        "ROM_NAME": rom_path.parent.name,
        "ROM_BRANCH": rom_path.name,
        "ANDROID_VERSION": android_version,
        "BUILD_JOBS": str(jobs),
        "BUILD_COMMAND": "" if str(payload.get("build_command", "default")).strip().lower() in {"", "default"} else str(payload.get("build_command", "")).strip().lower(),
        "BUILD_VARIANT": opts["build_variant"],
        "GAPPS_VARIANT": opts["gapps_variant"],
        "CLEAN_VARIANT": opts["clean_variant"],
        "INSTALLER_VARIANT": opts["installer_variant"],
        "USE_CCACHE": "1" if use_ccache else "2",
        "APN_VARIANT": "1" if custom_apn else "2",
        "CCACHE_DIR": str(Path.home() / ".cache" / "ccache"),
    })
    # Resolve config variables (for example $DEVICE_CODENAME) without invoking a shell.
    pattern = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)")
    for _ in range(10):
        changed = False
        for key, value in list(env.items()):
            if key in {"PATH", "HOME", "PWD", "SHELL"} or not isinstance(value, str):
                continue
            replaced = pattern.sub(lambda m: str(env.get(m.group(1) or m.group(2), m.group(0))), value)
            if replaced != value:
                env[key] = replaced
                changed = True
        if not changed:
            break
    return env, rom_path

# ── Persisted state helpers ──────────────────────────────────────────────────

def state_path(job_id: str) -> Path:
    if not isinstance(job_id, str) or not re.fullmatch(r"[a-f0-9-]{36}", job_id):
        raise ValueError("Invalid job ID.")
    return STATE_ROOT / f"{job_id}.json"

def read_state(job_id: str) -> dict[str, Any]:
    path = state_path(job_id)
    if not path.is_file():
        raise ValueError("Job not found.")
    return json.loads(path.read_text(encoding="utf-8"))

def write_state(state: dict[str, Any]) -> None:
    target = state_path(state["id"])
    temp = target.with_suffix(".tmp")
    temp.write_text(json.dumps(state, indent=2), encoding="utf-8")
    temp.replace(target)

def append_log(job_id: str, text: str) -> None:
    STATE_ROOT.mkdir(parents=True, exist_ok=True)
    with (STATE_ROOT / f"{job_id}.log").open("ab") as f:
        f.write(text.encode("utf-8", errors="replace"))
        f.flush()

def _pid_alive(pid: Any) -> bool:
    try:
        os.kill(int(pid), 0)
    except (ProcessLookupError, ValueError, TypeError):
        return False
    except PermissionError:
        return True
    return True

def refresh_state(state: dict[str, Any]) -> dict[str, Any]:
    """Mark a queued/running job failed when its worker died (crash, reboot, kill -9).

    Without this a dead worker leaves the job "running" forever and blocks every
    new task with "Another ROM Builder task is already running".
    """
    if state.get("status") not in {"queued", "running"}:
        return state
    pids = [state.get("pid"), state.get("worker_pid")]
    if any(pid and _pid_alive(pid) for pid in pids):
        return state
    created = state.get("created_at") or ""
    try:
        age = (datetime.now(timezone.utc) - datetime.fromisoformat(created)).total_seconds()
    except ValueError:
        age = 999
    if age < 15 and not any(pids):
        return state  # the worker has just been spawned and has not recorded its pid yet
    state.update(status="failed", message="The task worker stopped unexpectedly.", finished_at=now(), pid=None, exit_code=state.get("exit_code") if state.get("exit_code") is not None else 1)
    write_state(state)
    append_log(state["id"], f"\n[{now()}] The task worker stopped unexpectedly.\n")
    return state

def list_jobs() -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
    jobs: list[dict[str, Any]] = []
    STATE_ROOT.mkdir(parents=True, exist_ok=True)
    for item in sorted(STATE_ROOT.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            state = json.loads(item.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(state, dict) and "id" in state:
            jobs.append(refresh_state(state))
    jobs = jobs[:20]
    return jobs, next((j for j in jobs if j.get("status") in {"queued", "running"}), None)

# ── Console log reading (byte offsets, ANSI-aware) ────────────────────────────

_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)|\x1b[@-Z\\-_]")

def clean_terminal_text(text: str) -> str:
    """Plain text view of terminal output: no escape codes, \\r/\\b overwrites applied."""
    lines = []
    for line in _ANSI_RE.sub("", text).replace("\r\n", "\n").split("\n"):
        result = ""
        for piece in line.split("\r"):
            result = piece + result[len(piece):]
        while "\b" in result:
            index = result.index("\b")
            result = result[: max(0, index - 1)] + result[index + 1:]
        lines.append(result)
    return "\n".join(lines)

def read_log(job_id: str, offset: int = 0, tail_bytes: int = 0, max_bytes: int = 2_000_000, clean: bool = False) -> dict[str, Any]:
    state = read_state(job_id)
    path = STATE_ROOT / f"{job_id}.log"
    size = path.stat().st_size if path.exists() else 0
    start = max(0, size - tail_bytes) if tail_bytes > 0 else min(max(0, offset), size)
    data = b""
    if size and path.exists():
        with path.open("rb") as handle:
            handle.seek(start)
            data = handle.read(max_bytes)
    if tail_bytes > 0:  # do not start in the middle of a UTF-8 sequence
        skip = 0
        while skip < min(3, len(data)) and (data[skip] & 0xC0) == 0x80:
            skip += 1
        data, start = data[skip:], start + skip
    decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
    text = decoder.decode(data, final=False)
    consumed = len(data) - len(decoder.getstate()[0])
    return {
        "text": clean_terminal_text(text) if clean else text,
        "next_offset": start + consumed, "size": size, "status": state["status"],
    }

def tail_lines(job_id: str, lines: int = 60) -> str:
    text = read_log(job_id, tail_bytes=131072, clean=True)["text"]
    return "\n".join(text.rstrip("\n").split("\n")[-max(1, lines):])

# ── Persisted UI form state (shared by the web UI and the Agent) ──────────────

FORM_DEFAULTS: dict[str, Any] = {
    "rom_path": "", "device": "", "android_version": "16", "build_command": "default",
    "build_variant": "userdebug", "gapps_variant": "vanilla", "clean_variant": "full",
    "installer_variant": "custom", "build_jobs": 6, "use_ccache": True, "custom_apn": False,
}
ANDROID_VERSIONS = ["14", "15", "16", "17"]

def form_file() -> Path:
    return STATE_ROOT / "form.cfg"  # not *.json, so job listing never picks it up

def read_form() -> dict[str, Any]:
    data: dict[str, Any] = {}
    try:
        data = json.loads(form_file().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        pass
    saved = data.get("values") if isinstance(data.get("values"), dict) else {}
    return {
        "values": {**FORM_DEFAULTS, **{k: v for k, v in saved.items() if k in FORM_DEFAULTS}},
        "revision": int(data.get("revision", 0) or 0),
        "updated_at": data.get("updated_at"), "updated_by": data.get("updated_by"),
    }

def _as_bool(value: Any, key: str) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str) and value.strip().lower() in {"true", "1", "yes", "on"}:
        return True
    if isinstance(value, str) and value.strip().lower() in {"false", "0", "no", "off"}:
        return False
    if value in (0, 1):
        return bool(value)
    raise ValueError(f"'{key}' must be true or false.")

def coerce_form_values(raw: dict[str, Any]) -> dict[str, Any]:
    values: dict[str, Any] = {}
    for key, value in raw.items():
        if key not in FORM_DEFAULTS:
            raise ValueError(f"Unknown setting '{key}'. Valid settings: {', '.join(FORM_DEFAULTS)}.")
        if key in VARIANTS:
            text = str(value).strip().lower()
            if text not in VARIANTS[key]:
                raise ValueError(f"'{key}' must be one of: {', '.join(sorted(VARIANTS[key]))}.")
            values[key] = text
        elif key == "android_version":
            text = str(value).strip()
            if not re.fullmatch(r"\d{1,2}", text):
                raise ValueError("'android_version' must be a number such as 16.")
            values[key] = text
        elif key == "build_jobs":
            try:
                number = int(str(value).strip())
            except ValueError:
                raise ValueError("'build_jobs' must be a whole number.") from None
            if not 1 <= number <= 512:
                raise ValueError("'build_jobs' must be between 1 and 512.")
            values[key] = number
        elif key in {"use_ccache", "custom_apn"}:
            values[key] = _as_bool(value, key)
        elif key == "device":
            text = str(value).strip().lower()
            if text and not DEVICE_RE.fullmatch(text):
                raise ValueError("'device' must be a configured device name (letters, digits, - and _).")
            values[key] = text
        else:  # rom_path, build_command
            text = str(value).strip()
            if len(text) > 4096 or "\x00" in text:
                raise ValueError(f"'{key}' is too long or contains a NUL byte.")
            values[key] = text
    return values

def write_form(update: dict[str, Any], by: str = "agent") -> dict[str, Any]:
    current = read_form()
    values = {**current["values"], **coerce_form_values(update)}
    form = {"values": values, "revision": current["revision"] + 1, "updated_at": now(), "updated_by": by if by in {"ui", "agent"} else "agent"}
    STATE_ROOT.mkdir(parents=True, exist_ok=True)
    temp = form_file().with_suffix(".tmp")
    temp.write_text(json.dumps(form, indent=2), encoding="utf-8")
    temp.replace(form_file())
    return read_form()

def form_problems(values: dict[str, Any]) -> list[str]:
    try:
        build_environment(values)
    except ValueError as exc:
        return [str(exc)]
    return []

def load_config_into_form() -> dict[str, Any]:
    """Equivalent of the UI's "Load Configuration" button."""
    config = config_value(CONFIG_ROOT / "rom.conf")
    update: dict[str, Any] = {}
    device = str(config.get("DEVICE_CODENAME", "")).lower()
    if device and any(item["name"] == device for item in devices()):
        update["device"] = device
    wanted = str(config.get("DEFAULT_ROM_BUILD_COMMAND", "")).strip().lower()
    if wanted:
        for item in build_commands():
            label = item["label"].lower()
            if item["id"].lower() == wanted or wanted in label or label.split("-->")[-1].strip() == wanted:
                update["build_command"] = item["id"]
                break
    form = write_form(update, by="agent") if update else read_form()
    return {"applied": update, "form": form}

# ── Terminal input (keys → bytes) ─────────────────────────────────────────────

KEY_BYTES = {
    "enter": "\r", "return": "\r", "tab": "\t", "esc": "\x1b", "escape": "\x1b", "space": " ",
    "backspace": "\x7f", "delete": "\x1b[3~", "up": "\x1b[A", "down": "\x1b[B", "right": "\x1b[C",
    "left": "\x1b[D", "home": "\x1b[H", "end": "\x1b[F", "pageup": "\x1b[5~", "pagedown": "\x1b[6~",
}

def keys_to_text(spec: str) -> str:
    """"y,Enter,Ctrl-C" → bytes to type. Unknown multi-character tokens are typed literally."""
    out = []
    for token in [t for t in spec.split(",") if t != ""]:
        lowered = token.strip().lower()
        if lowered in KEY_BYTES:
            out.append(KEY_BYTES[lowered])
        elif re.fullmatch(r"(ctrl|c)[-+][a-z\[\]\\^_]", lowered):
            out.append(chr(ord(lowered[-1].upper()) & 0x1F))
        else:
            out.append(token)
    return "".join(out)

def queue_terminal_input(job_id: str, text: str, raw: bool = False) -> dict[str, Any]:
    state = refresh_state(read_state(job_id))
    if state.get("status") != "running":
        raise ValueError("Terminal input is available only while a ROM Builder task is running.")
    if not isinstance(text, str) or not text or "\x00" in text:
        raise ValueError("Terminal input must be non-empty and contain no NUL bytes.")
    data = text.encode("utf-8", errors="replace")
    if not raw and not data.endswith((b"\n", b"\r")):
        data += b"\n"
    if len(data) > 4096:
        raise ValueError("Terminal input is limited to 4096 bytes per request.")
    STATE_ROOT.mkdir(parents=True, exist_ok=True)
    fd = os.open(STATE_ROOT / f"{job_id}.stdin", os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    try:
        os.write(fd, data)
    finally:
        os.close(fd)
    return {"ok": True, "id": job_id, "bytes": len(data)}

# ── Job execution (runs the script inside a pseudo-terminal) ──────────────────

def _run_in_pty(job_id: str, script: Path, cwd: Path, env: dict[str, str]) -> int:
    """Run the script attached to a real TTY so prompts, colours and Ctrl-keys behave like a terminal."""
    master, slave = os.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 40, 160, 0, 0))
    env = {**env, "TERM": env.get("TERM") or "xterm-256color", "COLUMNS": "160", "LINES": "40"}

    def attach_controlling_tty() -> None:
        try:
            fcntl.ioctl(0, termios.TIOCSCTTY, 0)
        except OSError:
            pass

    proc = subprocess.Popen(
        ["bash", str(script)], cwd=str(cwd), env=env,
        stdin=slave, stdout=slave, stderr=slave,
        start_new_session=True, close_fds=True, preexec_fn=attach_controlling_tty,
    )
    os.close(slave)
    state = read_state(job_id)
    state["pid"] = proc.pid
    write_state(state)
    log_path = STATE_ROOT / f"{job_id}.log"
    input_path = STATE_ROOT / f"{job_id}.stdin"

    def pump_output() -> None:
        with log_path.open("ab", buffering=0) as log:
            while True:
                ready, _, _ = select.select([master], [], [], 0.2)
                if ready:
                    try:
                        data = os.read(master, 65536)
                    except OSError:
                        break
                    if not data:
                        break
                    log.write(data)
                elif proc.poll() is not None:
                    try:
                        while select.select([master], [], [], 0)[0]:
                            data = os.read(master, 65536)
                            if not data:
                                break
                            log.write(data)
                    except OSError:
                        pass
                    break

    def forward_input() -> None:
        offset = 0
        while proc.poll() is None:
            try:
                with input_path.open("rb") as queued:
                    queued.seek(offset)
                    chunk = queued.read(4096)
                if chunk:
                    view = memoryview(chunk)
                    while view:
                        written = os.write(master, view)
                        view = view[written:]
                    offset += len(chunk)
                    continue
            except FileNotFoundError:
                pass
            except OSError:
                break
            time.sleep(0.03)

    output_thread = threading.Thread(target=pump_output, daemon=True)
    input_thread = threading.Thread(target=forward_input, daemon=True)
    output_thread.start()
    input_thread.start()
    code = proc.wait()
    output_thread.join(timeout=3)
    input_thread.join(timeout=0.5)
    try:
        os.close(master)
    except OSError:
        pass
    return code

def run_job(job_id: str, action: str, payload: dict[str, Any]) -> None:
    state = read_state(job_id)
    try:
        env, rom_path = build_environment(payload)
        if action == "clean":
            env["USER_CLEAN"] = "true"
        script_rel = ALLOWED_ACTIONS[action]
        script = (ROOT / script_rel).resolve()
        if not script.is_file() or ROOT not in script.parents:
            raise ValueError("The requested ROM Builder script is not available.")
        state.update(status="running", started_at=now(), pid=None, message=f"Running {action}")
        write_state(state)
        # Android build scripts expect to execute inside the checked-out ROM
        # source tree: build/envsetup.sh, lunch and brunch are relative to it.
        # Non-build helper actions retain the addon root as their working dir.
        action_cwd = rom_path if action == "build" else ROOT
        append_log(job_id, f"[{now()}] Action: {action}\nROM source: {rom_path}\nWorking directory: {action_cwd}\nScript: {script_rel}\n\n")
        code = _run_in_pty(job_id, script, action_cwd, env)
        state = read_state(job_id)
        if state.get("status") == "cancelled":
            state.update(pid=None, worker_pid=None)
            write_state(state)
            return
        state.update(
            status="succeeded" if code == 0 else "failed",
            exit_code=code,
            finished_at=now(),
            message="Completed successfully." if code == 0 else f"Script exited with code {code}.",
            pid=None,
            worker_pid=None,
        )
        append_log(job_id, f"\n[{now()}] Finished with exit code {code}.\n")
        write_state(state)
    except Exception as exc:
        state = read_state(job_id)
        state.update(status="failed", message=str(exc), finished_at=now(), pid=None, exit_code=1)
        append_log(job_id, f"\n[{now()}] ERROR: {exc}\n")
        write_state(state)

def start_job(action: str, payload: dict[str, Any]) -> dict[str, Any]:
    if action not in ALLOWED_ACTIONS:
        raise ValueError("Unsupported ROM Builder action.")
    # Validate before creating a job so bad requests never start a process.
    _, source_path = build_environment(payload)
    if action == "build" and not (source_path / "build" / "envsetup.sh").is_file():
        raise ValueError("Android source tree is missing build/envsetup.sh. Sync or initialize a complete Android source tree before building.")
    STATE_ROOT.mkdir(parents=True, exist_ok=True)
    _, active = list_jobs()
    if active:
        raise ValueError("Another ROM Builder task is already running. Wait for it to finish or cancel it first.")
    job_id = str(uuid.uuid4())
    state = {
        "id": job_id, "action": action, "status": "queued",
        "created_at": now(), "started_at": None, "finished_at": None,
        "exit_code": None, "pid": None, "message": "Queued",
    }
    write_state(state)
    worker_payload = json.dumps(payload, separators=(",", ":"))
    worker = subprocess.Popen(
        [sys.executable, "-S", str(Path(__file__).resolve()), "worker",
         "--job-id", job_id, "--action", action, "--payload", worker_payload],
        cwd=str(ROOT),
        env={**os.environ, "ATEAM_ROM_BUILDER_STATE": str(STATE_ROOT)},
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
        close_fds=True,
    )
    latest = read_state(job_id)
    latest["worker_pid"] = worker.pid
    write_state(latest)
    return latest

def cancel_job(job_id: str) -> dict[str, Any]:
    state = refresh_state(read_state(job_id))
    pid = state.get("pid")
    if state.get("status") not in {"queued", "running"} or not pid:
        raise ValueError("This job is not currently running.")
    try:
        os.killpg(int(pid), 15)
    except ProcessLookupError:
        pass
    state.update(status="cancelled", message="Cancelled by user.", finished_at=now(), pid=None)
    write_state(state)
    append_log(job_id, f"\n[{now()}] Cancel requested.\n")
    return state

# ── Self-description for the Agent: every control, button and output ──────────

def spec() -> dict[str, Any]:
    cpu_cap = max(1, (os.cpu_count() or 8) * 2)
    device_names = [item["name"] for item in devices()]
    command_ids = [item["id"] for item in build_commands()]
    return {
        "app": "ROM Builder", "spec_version": 2,
        "how_to_use": "Set form fields with form-set, press a button with run, watch progress with snapshot/logs, type into the console with keys/input. Everything the UI shows is readable with snapshot.",
        "controls": [
            {"id": "rom_path", "ui_label": "Android source directory", "kind": "text input + Browse button", "type": "path", "default": "", "agent": "form-set --payload '{\"rom_path\":\"/path/to/checkout\"}'", "notes": "Must contain build/, device/ and build/envsetup.sh. Browse opens a native folder picker for the human; the Agent sets the path directly."},
            {"id": "device", "ui_label": "Device", "kind": "dropdown", "type": "enum", "options": device_names, "default": "", "agent": "form-set --payload '{\"device\":\"<name>\"}'"},
            {"id": "android_version", "ui_label": "Android version", "kind": "dropdown", "type": "enum", "options": ANDROID_VERSIONS, "default": "16"},
            {"id": "build_command", "ui_label": "Known ROM build command", "kind": "dropdown", "type": "enum", "options": command_ids, "default": "default", "notes": "'default' uses rom.conf. See the 'commands' command for labels."},
            {"id": "build_variant", "ui_label": "Build variant", "kind": "dropdown", "type": "enum", "options": sorted(VARIANTS["build_variant"]), "default": "userdebug"},
            {"id": "gapps_variant", "ui_label": "GApps variant", "kind": "dropdown", "type": "enum", "options": sorted(VARIANTS["gapps_variant"]), "default": "vanilla"},
            {"id": "clean_variant", "ui_label": "Clean variant", "kind": "dropdown", "type": "enum", "options": sorted(VARIANTS["clean_variant"]), "default": "full"},
            {"id": "installer_variant", "ui_label": "Installer variant", "kind": "dropdown", "type": "enum", "options": sorted(VARIANTS["installer_variant"]), "default": "custom"},
            {"id": "build_jobs", "ui_label": "Build jobs", "kind": "number input", "type": "integer", "min": 1, "max": cpu_cap, "default": 6, "notes": f"Runs reject values above {cpu_cap} (2 x CPU threads)."},
            {"id": "use_ccache", "ui_label": "Use ccache", "kind": "switch", "type": "boolean", "default": True},
            {"id": "custom_apn", "ui_label": "Custom APN", "kind": "switch", "type": "boolean", "default": False},
        ],
        "buttons": [
            {"id": "build", "ui_label": "Build ROM", "agent": "run --action build", "does": "Runs scripts/build.sh inside the Android source tree with the current form values.", "long_running": True},
            {"id": "sync", "ui_label": "Sync source", "agent": "run --action sync", "does": "Runs the device-source sync workflow (scripts/sync.sh).", "long_running": True},
            {"id": "gapps-sync", "ui_label": "Sync GApps", "agent": "run --action gapps-sync", "does": "Runs the GApps sync workflow.", "long_running": True},
            {"id": "setup", "ui_label": "A-Team setup", "agent": "run --action setup", "does": "Runs the bundled A-Team setup script.", "long_running": True},
            {"id": "upload", "ui_label": "Upload build", "agent": "run --action upload", "does": "Runs the configured upload workflow.", "long_running": True},
            {"id": "clean", "ui_label": "Clean", "agent": "run --action clean", "does": "Runs the clean workflow using the Clean variant. DESTRUCTIVE: removes build outputs; confirm with the user first.", "long_running": True, "destructive": True},
            {"id": "load_configuration", "ui_label": "Load Configuration", "agent": "load-config", "does": "Copies DEVICE_CODENAME and DEFAULT_ROM_BUILD_COMMAND from rom.conf into the form."},
            {"id": "refresh_configuration", "ui_label": "Refresh configuration", "agent": "config (or devices / hosts / commands)", "does": "Re-reads device, host and command lists from disk."},
            {"id": "cancel_task", "ui_label": "Cancel task", "agent": "cancel --job-id <id>", "does": "Stops the running task (SIGTERM to its process group)."},
            {"id": "browse", "ui_label": "Browse", "agent": "form-set --payload '{\"rom_path\":...}'", "does": "Human-only native folder dialog; the Agent sets rom_path directly."},
        ],
        "terminal": {"ui_label": "Build Console", "interactive": True, "agent_read": "logs --job-id <id> --clean | shell-poll --session-id <id> --offset <bytes> | snapshot", "agent_type": "shell-start --cwd <rom_path>; shell-input --session-id <id> --text <bytes>; shell-stop --session-id <id>; task input/keys remain available for active jobs", "key_names": sorted(KEY_BYTES) + ["Ctrl-<letter>"], "notes": "After Load Configuration, the UI opens a persistent interactive bash shell in the selected Android source directory. The shell uses a real pseudo-terminal (TERM=xterm-256color, 160x40); prompts, colours, arrows, Enter, Tab and Ctrl+C work. Build tasks continue to use their own pseudo-terminal and job logs. Full-screen programs are not rendered by the UI."},
        "outputs": [
            {"id": "job_status", "ui": "Build Console header", "agent": "status --job-id <id> | snapshot"},
            {"id": "console_log", "ui": "Build Console terminal", "agent": "logs --job-id <id> [--offset N] [--clean] | snapshot.log_tail"},
            {"id": "resource_monitor", "ui": "Resource Monitor pane", "agent": "sensors | snapshot.sensors", "fields": ["cpu.tempC", "cpu.usagePercent", "cpu.speedMHz", "cpu.physicalCores", "cpu.logicalThreads", "memory.percent", "gpus[].tempC", "gpus[].usagePercent", "gpus[].speedMHz", "gpus[].vramUsedBytes", "gpus[].vramTotalBytes"]},
            {"id": "agent_context", "ui": "Agent Integration pane", "agent": "list | snapshot.active_job"},
            {"id": "errors", "ui": "red alert banner", "agent": "snapshot.problems (why a run would be refused)"},
        ],
        "commands": ["spec", "snapshot", "poll", "form-get", "form-set", "load-config", "run", "sensors", "devices", "hosts", "commands", "config", "list", "status", "logs", "keys", "input", "shell-start", "shell-poll", "shell-input", "shell-stop", "cancel", "shutdown"],
    }

def snapshot(tail: int = 60, job_id: str | None = None) -> dict[str, Any]:
    form = read_form()
    jobs, active = list_jobs()
    target = None
    if job_id:
        target = refresh_state(read_state(job_id))
    else:
        target = active or (jobs[0] if jobs else None)
    problems = form_problems(form["values"])
    log: dict[str, Any] | None = None
    if target:
        log = {"job_id": target["id"], "tail": tail_lines(target["id"], tail), "next_offset": read_log(target["id"], tail_bytes=1)["size"]}
    try:
        from sensors import collect  # local module next to this file
        sensor_data = collect(0.2)
    except Exception as exc:  # sensors are supplemental; never fail the snapshot
        sensor_data = {"error": str(exc)}
    return {
        "sampled_at": now(), "form": form, "problems": problems,
        "can_run": not problems and active is None,
        "active_job": active, "selected_job": target, "recent_jobs": jobs[:5],
        "log": log, "sensors": sensor_data,
        "available": {"devices": devices(), "build_commands": build_commands(), "hosts": hosts(), "android_versions": ANDROID_VERSIONS},
    }



# ── Persistent interactive Build Console shell ───────────────────────────────

def shell_state_path(session_id: str) -> Path:
    if not isinstance(session_id, str) or not re.fullmatch(r"[a-f0-9-]{36}", session_id):
        raise ValueError("Invalid terminal session ID.")
    return STATE_ROOT / f"shell-{session_id}.json"

def read_shell_state(session_id: str) -> dict[str, Any]:
    path = shell_state_path(session_id)
    if not path.is_file():
        raise ValueError("Terminal session not found.")
    return json.loads(path.read_text(encoding="utf-8"))

def write_shell_state(state: dict[str, Any]) -> None:
    path = shell_state_path(state["id"])
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(state, indent=2), encoding="utf-8")
    os.replace(temp, path)

def start_shell(cwd_value: str) -> dict[str, Any]:
    cwd = safe_rom_path(cwd_value)
    STATE_ROOT.mkdir(parents=True, exist_ok=True)
    session_id = str(uuid.uuid4())
    state = {"id": session_id, "status": "starting", "cwd": str(cwd), "created_at": now(), "pid": None, "shell_pid": None}
    write_shell_state(state)
    worker = subprocess.Popen(
        [sys.executable, "-S", str(Path(__file__).resolve()), "shell-worker",
         "--session-id", session_id, "--cwd", str(cwd)],
        cwd=str(ROOT), env={**os.environ, "ATEAM_ROM_BUILDER_STATE": str(STATE_ROOT)},
        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        start_new_session=True, close_fds=True,
    )
    latest = read_shell_state(session_id)
    latest["pid"] = worker.pid
    write_shell_state(latest)
    return latest

def shell_worker(session_id: str, cwd_value: str) -> None:
    cwd = safe_rom_path(cwd_value)
    master, slave = os.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 40, 160, 0, 0))
    env = {**os.environ, "TERM": os.environ.get("TERM") or "xterm-256color", "COLUMNS": "160", "LINES": "40",
           "PS1": r"\[\e[1;36m\]\w\[\e[0m\] $ ", "PROMPT_COMMAND": ""}
    def attach_tty() -> None:
        try: fcntl.ioctl(0, termios.TIOCSCTTY, 0)
        except OSError: pass
    proc = subprocess.Popen(["bash", "--noprofile", "--norc", "-i"], cwd=str(cwd), env=env,
        stdin=slave, stdout=slave, stderr=slave, start_new_session=True, close_fds=True, preexec_fn=attach_tty)
    os.close(slave)
    state = read_shell_state(session_id)
    state.update(status="running", shell_pid=proc.pid, started_at=now())
    write_shell_state(state)
    log_path = STATE_ROOT / f"shell-{session_id}.log"
    input_path = STATE_ROOT / f"shell-{session_id}.stdin"
    input_offset = 0
    try:
        with log_path.open("ab", buffering=0) as log:
            while proc.poll() is None:
                try:
                    if input_path.is_file():
                        with input_path.open("rb") as stream:
                            stream.seek(input_offset)
                            data = stream.read(4096)
                            input_offset += len(data)
                        if data:
                            os.write(master, data)
                    ready, _, _ = select.select([master], [], [], 0.08)
                    if ready:
                        try:
                            data = os.read(master, 65536)
                            if data: log.write(data)
                        except OSError:
                            break
                except (BrokenPipeError, OSError):
                    break
    finally:
        try: os.close(master)
        except OSError: pass
        if proc.poll() is None:
            try: os.killpg(proc.pid, 15)
            except ProcessLookupError: pass
            try: proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                try: os.killpg(proc.pid, 9)
                except ProcessLookupError: pass
        try:
            state = read_shell_state(session_id)
            state.update(status="closed", shell_pid=None, finished_at=now())
            write_shell_state(state)
        except Exception:
            pass

def send_shell_input(session_id: str, text: str) -> dict[str, Any]:
    state = read_shell_state(session_id)
    if state.get("status") != "running":
        raise ValueError("The Build Console shell is not running.")
    if not isinstance(text, str) or not text or "\x00" in text or len(text.encode("utf-8", errors="replace")) > 4096:
        raise ValueError("Terminal input must be 1–4096 bytes and contain no NUL bytes.")
    with (STATE_ROOT / f"shell-{session_id}.stdin").open("ab") as stream:
        stream.write(text.encode("utf-8", errors="replace"))
    return {"ok": True, "id": session_id}

def read_shell_log(session_id: str, offset: int = 0) -> dict[str, Any]:
    read_shell_state(session_id)
    path = STATE_ROOT / f"shell-{session_id}.log"
    if not path.exists(): return {"text": "", "next_offset": 0, "size": 0}
    with path.open("rb") as stream:
        size = path.stat().st_size
        stream.seek(max(0, offset))
        data = stream.read(262144)
    return {"text": data.decode("utf-8", errors="replace"), "next_offset": max(0, offset) + len(data), "size": size}

def stop_shell(session_id: str) -> dict[str, Any]:
    state = read_shell_state(session_id)
    for pid in (state.get("shell_pid"), state.get("pid")):
        if pid:
            try: os.killpg(int(pid), 15)
            except (ProcessLookupError, PermissionError, ValueError):
                try: os.kill(int(pid), 15)
                except (ProcessLookupError, PermissionError, ValueError): pass
    state.update(status="closed", shell_pid=None, finished_at=now())
    write_shell_state(state)
    return {"ok": True, "id": session_id}


# ── Command line ──────────────────────────────────────────────────────────────

def command_main() -> int:
    parser = argparse.ArgumentParser(description="ROM Builder control surface for the A-Team Agent (JSON in/out).")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("spec", help="Describe every control, button and output (read this first)")
    snap = sub.add_parser("snapshot", help="Everything the UI shows: form, status, log tail, sensors")
    snap.add_argument("--tail-lines", type=int, default=60)
    snap.add_argument("--job-id")
    sub.add_parser("form-get", help="Current form values (shared with the web UI)")
    form_set = sub.add_parser("form-set", help="Change form values (shared with the web UI)")
    form_set.add_argument("--payload", required=True, help="JSON object of fields to change")
    form_set.add_argument("--by", default="agent")
    sub.add_parser("load-config", help="Press Load Configuration")
    run = sub.add_parser("run", help="Press an action button using the saved form values")
    run.add_argument("--action", required=True)
    run.add_argument("--payload", default="{}", help="Optional JSON overrides for this run only")
    run.add_argument("--wait", type=float, default=0, help="Seconds to wait for completion before returning")
    sub.add_parser("sensors", help="CPU/GPU/RAM/VRAM readings")
    sub.add_parser("devices")
    sub.add_parser("hosts")
    sub.add_parser("commands")
    sub.add_parser("config")
    start = sub.add_parser("start")
    start.add_argument("--action", required=True)
    start.add_argument("--payload", required=True, help="JSON encoded request")
    status = sub.add_parser("status")
    status.add_argument("--job-id", required=True)
    sub.add_parser("list", help="List persisted ROM Builder jobs for Agent context")
    sub.add_parser("shutdown", help="Stop active ROM Builder jobs started by this app")
    logs = sub.add_parser("logs")
    logs.add_argument("--job-id", required=True)
    logs.add_argument("--offset", type=int, default=0, help="Byte offset from a previous next_offset")
    logs.add_argument("--tail-bytes", type=int, default=0, help="Return only the last N bytes")
    logs.add_argument("--clean", action="store_true", help="Strip escape codes and apply \\r overwrites")
    poll = sub.add_parser("poll", help="Status plus a log chunk in one call (used by the UI)")
    poll.add_argument("--job-id", required=True)
    poll.add_argument("--offset", type=int, default=0)
    poll.add_argument("--tail-bytes", type=int, default=0)
    cancel = sub.add_parser("cancel")
    cancel.add_argument("--job-id", required=True)
    terminal_input = sub.add_parser("input")
    terminal_input.add_argument("--job-id", required=True)
    terminal_input.add_argument("--text", required=True)
    terminal_input.add_argument("--raw", action="store_true", help="Send bytes exactly as given (no Enter appended)")
    keys = sub.add_parser("keys", help="Type keys, e.g. --keys 'y,Enter' or 'Ctrl-C'")
    keys.add_argument("--job-id", required=True)
    keys.add_argument("--keys", required=True)
    shell_start = sub.add_parser("shell-start")
    shell_start.add_argument("--cwd", required=True)
    shell_input = sub.add_parser("shell-input")
    shell_input.add_argument("--session-id", required=True)
    shell_input.add_argument("--text", required=True)
    shell_poll = sub.add_parser("shell-poll")
    shell_poll.add_argument("--session-id", required=True)
    shell_poll.add_argument("--offset", type=int, default=0)
    shell_stop = sub.add_parser("shell-stop")
    shell_stop.add_argument("--session-id", required=True)
    shell_worker_parser = sub.add_parser("shell-worker")
    shell_worker_parser.add_argument("--session-id", required=True)
    shell_worker_parser.add_argument("--cwd", required=True)
    worker = sub.add_parser("worker")
    worker.add_argument("--job-id", required=True)
    worker.add_argument("--action", required=True)
    worker.add_argument("--payload", required=True)
    args = parser.parse_args()
    try:
        if args.command == "spec":
            emit(spec())
        elif args.command == "snapshot":
            emit(snapshot(args.tail_lines, args.job_id))
        elif args.command == "form-get":
            emit(read_form())
        elif args.command == "form-set":
            payload = json.loads(args.payload)
            if not isinstance(payload, dict):
                raise ValueError("Payload must be a JSON object.")
            emit(write_form(payload, by=args.by))
        elif args.command == "load-config":
            emit(load_config_into_form())
        elif args.command == "run":
            overrides = json.loads(args.payload)
            if not isinstance(overrides, dict):
                raise ValueError("Payload must be a JSON object.")
            payload = {**read_form()["values"], **coerce_form_values(overrides)}
            started = start_job(args.action, payload)
            deadline = time.time() + max(0.0, args.wait)
            while args.wait and time.time() < deadline:
                time.sleep(1)
                started = refresh_state(read_state(started["id"]))
                if started["status"] not in {"queued", "running"}:
                    break
            emit({"job": started, "log_tail": tail_lines(started["id"], 40)})
        elif args.command == "sensors":
            from sensors import collect
            emit(collect())
        elif args.command == "devices":
            emit({"devices": devices()})
        elif args.command == "hosts":
            emit({"hosts": hosts()})
        elif args.command == "commands":
            emit({"commands": build_commands()})
        elif args.command == "config":
            emit({"rom_config": config_value(CONFIG_ROOT / "rom.conf"), "devices": devices(), "hosts": hosts(), "commands": build_commands()})
        elif args.command == "start":
            payload = json.loads(args.payload)
            if not isinstance(payload, dict):
                raise ValueError("Request payload must be a JSON object.")
            emit(start_job(args.action, payload))
        elif args.command == "status":
            emit(refresh_state(read_state(args.job_id)))
        elif args.command == "list":
            jobs, active = list_jobs()
            emit({"jobs": jobs, "active": active})
        elif args.command == "shutdown":
            stopped = []
            STATE_ROOT.mkdir(parents=True, exist_ok=True)
            for item in STATE_ROOT.glob("*.json"):
                try: state = json.loads(item.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError): continue
                if not isinstance(state, dict) or state.get("status") not in {"queued", "running"}: continue
                pid = state.get("pid") or state.get("worker_pid")
                if pid:
                    try: os.killpg(int(pid), 15)
                    except ProcessLookupError: pass
                    except (PermissionError, ValueError):
                        try: os.kill(int(pid), 15)
                        except (ProcessLookupError, PermissionError, ValueError): pass
                state.update(status="cancelled", message="Stopped because A-Team Agent closed.", finished_at=now(), pid=None)
                write_state(state); append_log(state["id"], f"\n[{now()}] App shutdown requested; task stopped.\n"); stopped.append(state["id"])
            emit({"ok": True, "stopped": stopped})
        elif args.command == "logs":
            emit(read_log(args.job_id, args.offset, args.tail_bytes, clean=args.clean))
        elif args.command == "poll":
            try:
                status_data = refresh_state(read_state(args.job_id))
            except ValueError as exc:
                if str(exc) != "Job not found.":
                    raise
                # A stale/foreign job ID should be a readable poll result, not
                # a failed process invocation that hides the useful error from
                # Agent command runners.
                emit({"status": {"id": args.job_id, "status": "not_found",
                                 "message": "No ROM Builder job state exists in the shared project state directory.",
                                 "state_directory": str(STATE_ROOT)},
                      "logs": {"text": "", "next_offset": 0, "size": 0}})
            else:
                emit({"status": status_data, "logs": read_log(args.job_id, args.offset, args.tail_bytes)})
        elif args.command == "shell-start":
            emit(start_shell(args.cwd))
        elif args.command == "shell-input":
            emit(send_shell_input(args.session_id, args.text))
        elif args.command == "shell-poll":
            state = read_shell_state(args.session_id)
            emit({"status": state, "logs": read_shell_log(args.session_id, args.offset)})
        elif args.command == "shell-stop":
            emit(stop_shell(args.session_id))
        elif args.command == "shell-worker":
            shell_worker(args.session_id, args.cwd)
            emit({"ok": True})
        elif args.command == "worker":
            payload = json.loads(args.payload)
            run_job(args.job_id, args.action, payload)
            emit(read_state(args.job_id))
        elif args.command == "cancel":
            emit(cancel_job(args.job_id))
        elif args.command == "input":
            emit(queue_terminal_input(args.job_id, args.text, raw=args.raw))
        elif args.command == "keys":
            emit(queue_terminal_input(args.job_id, keys_to_text(args.keys), raw=True))
        return 0
    except Exception as exc:
        emit({"error": str(exc)})
        return 2

if __name__ == "__main__":
    raise SystemExit(command_main())
