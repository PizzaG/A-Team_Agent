#!/usr/bin/env python3
"""Agent-controlled ROM Builder command runner.

This is the supported CLI boundary between the Agent UI and the existing
ROM Builder scripts. It accepts JSON requests, validates them, persists job
state/logs, and runs only allow-listed ROM Builder scripts.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
STATE_ROOT = Path(os.environ.get(
    "ATEAM_ROM_BUILDER_STATE",
    str(Path.home() / ".local" / "share" / "a-team-agent" / "rom-builder"),
)).expanduser()
CONFIG_ROOT = ROOT / "configs"
ALLOWED_ACTIONS = {
    "build": "scripts/build.sh",
    "sync": "scripts/sync.sh",
    "gapps-sync": "scripts/gapps_sync.sh",
    "clean": "scripts/clean.sh",
    "setup": "scripts/a-team_setup.sh",
    "upload": "scripts/upload.sh",
}
DEVICE_RE = re.compile(r"^[a-zA-Z0-9_-]{1,80}$")
VARIANTS = {
    "build_variant": {"user", "userdebug", "eng"},
    "gapps_variant": {"vanilla", "gapps", "micro-g", "foss"},
    "clean_variant": {"full", "lite", "none"},
    "installer_variant": {"custom", "default"},
}

def now() -> str:
    return datetime.now(timezone.utc).isoformat()

def emit(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=False))

def config_value(path: Path) -> dict[str, str]:
    data: dict[str, str] = {}
    if not path.is_file():
        return data
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip().strip('"').strip("'")
        data[key.strip()] = value
    return data

def devices() -> list[dict[str, str]]:
    results = []
    for path in sorted((CONFIG_ROOT / "devices").glob("*.conf")):
        data = config_value(path)
        results.append({
            "name": path.stem.lower(),
            "display": data.get("DEVICE_DISPLAY_NAME", path.stem.capitalize()),
            "codename": data.get("DEVICE_CODENAME", path.stem.lower()),
        })
    return sorted(results, key=lambda item: item["display"].lower())

def build_commands() -> list[dict[str, str]]:
    path = CONFIG_ROOT / "rom_build_commands.conf"
    results = []
    if not path.is_file():
        return [{"id": "", "label": "Default (rom.conf)"}]
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "-->" in line:
            label, value = [part.strip() for part in line.split("-->", 1)]
            results.append({"id": "default" if label.lower() == "default" else value.lower(), "label": line})
        else:
            results.append({"id": line.strip().lower(), "label": line.strip()})
    return results or [{"id": "", "label": "Default (rom.conf)"}]

def hosts() -> list[dict[str, str]]:
    path = CONFIG_ROOT / "hosts.conf"
    sections: list[dict[str, str]] = []
    current: dict[str, str] | None = None
    if not path.is_file():
        return [{"name": "Local", "kind": "local"}]
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith(("#", ";")):
            continue
        if line.startswith("[") and line.endswith("]"):
            if current:
                sections.append(current)
            name = line[1:-1].strip()
            current = {"name": name, "kind": "local" if name.lower() == "local" else "remote"}
        elif current and "=" in line:
            key, value = line.split("=", 1)
            current[key.strip()] = value.strip()
    if current:
        sections.append(current)
    return [h for h in sections if h["kind"] == "local" or h.get("server_address")]

def safe_rom_path(value: Any) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Choose a ROM source directory first.")
    path = Path(value).expanduser().resolve()
    if not path.is_dir():
        raise ValueError(f"ROM source directory does not exist: {path}")
    if not (path / "build").is_dir() or not (path / "device").is_dir():
        raise ValueError("The selected directory does not look like an Android source tree (expected build/ and device/).")
    if not (path / "build" / "envsetup.sh").is_file():
        raise ValueError(f"The selected source directory is missing build/envsetup.sh: {path}. Select the Android ROM checkout root, not a parent folder or output folder.")
    return path

def build_environment(payload: dict[str, Any]) -> tuple[dict[str, str], Path]:
    device = str(payload.get("device", "")).strip().lower()
    if not DEVICE_RE.fullmatch(device):
        raise ValueError("Select a valid configured device.")
    device_file = CONFIG_ROOT / "devices" / f"{device}.conf"
    if not device_file.is_file():
        raise ValueError(f"No ROM Builder device configuration exists for '{device}'.")
    rom_path = safe_rom_path(payload.get("rom_path"))
    android_version = str(payload.get("android_version", "16")).strip()
    if not re.fullmatch(r"\d{1,2}", android_version):
        raise ValueError("Android version must be a numeric version.")
    jobs = payload.get("build_jobs", 6)
    if isinstance(jobs, bool) or not isinstance(jobs, int) or not 1 <= jobs <= max(1, (os.cpu_count() or 8) * 2):
        raise ValueError("Build jobs must be a positive integer within the supported CPU limit.")
    opts: dict[str, str] = {}
    for field, allowed in VARIANTS.items():
        value = str(payload.get(field, {
            "build_variant": "userdebug",
            "gapps_variant": "vanilla",
            "clean_variant": "full",
            "installer_variant": "custom",
        }[field])).lower()
        if value not in allowed:
            raise ValueError(f"Unsupported {field.replace('_', ' ')}: {value}")
        opts[field] = value
    custom_apn = bool(payload.get("custom_apn", False))
    use_ccache = bool(payload.get("use_ccache", True))
    env = os.environ.copy()
    env.update(config_value(CONFIG_ROOT / "a_team_setup.conf"))
    env.update(config_value(device_file))
    rom_config = rom_path / "rom.conf"
    env.update(config_value(rom_config if rom_config.is_file() else CONFIG_ROOT / "rom.conf"))
    env.update({
        "DEVICE_NAME": device,
        "ROM_PATH": str(rom_path),
        "ROM_NAME": rom_path.parent.name,
        "ROM_BRANCH": rom_path.name,
        "ANDROID_VERSION": android_version,
        "BUILD_JOBS": str(jobs),
        "BUILD_COMMAND": "" if str(payload.get("build_command", "default")).strip().lower() in {"", "default"} else str(payload.get("build_command", "")).strip().lower(),
        "BUILD_VARIANT": opts["build_variant"],
        "GAPPS_VARIANT": opts["gapps_variant"],
        "CLEAN_VARIANT": opts["clean_variant"],
        "INSTALLER_VARIANT": opts["installer_variant"],
        "USE_CCACHE": "1" if use_ccache else "2",
        "APN_VARIANT": "1" if custom_apn else "2",
        "CCACHE_DIR": str(Path.home() / ".cache" / "ccache"),
    })
    # Resolve config variables (for example $DEVICE_CODENAME) without invoking a shell.
    pattern = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)")
    for _ in range(10):
        changed = False
        for key, value in list(env.items()):
            if key in {"PATH", "HOME", "PWD", "SHELL"} or not isinstance(value, str):
                continue
            replaced = pattern.sub(lambda m: str(env.get(m.group(1) or m.group(2), m.group(0))), value)
            if replaced != value:
                env[key] = replaced
                changed = True
        if not changed:
            break
    return env, rom_path

def state_path(job_id: str) -> Path:
    if not re.fullmatch(r"[a-f0-9-]{36}", job_id):
        raise ValueError("Invalid job ID.")
    return STATE_ROOT / f"{job_id}.json"

def read_state(job_id: str) -> dict[str, Any]:
    path = state_path(job_id)
    if not path.is_file():
        raise ValueError("Job not found.")
    return json.loads(path.read_text(encoding="utf-8"))

def write_state(state: dict[str, Any]) -> None:
    target = state_path(state["id"])
    temp = target.with_suffix(".tmp")
    temp.write_text(json.dumps(state, indent=2), encoding="utf-8")
    temp.replace(target)

def append_log(job_id: str, text: str) -> None:
    STATE_ROOT.mkdir(parents=True, exist_ok=True)
    with (STATE_ROOT / f"{job_id}.log").open("a", encoding="utf-8", errors="replace") as f:
        f.write(text)
        f.flush()

def queue_terminal_input(job_id: str, text: str) -> dict[str, Any]:
    state = read_state(job_id)
    if state.get("status") != "running":
        raise ValueError("Terminal input is available only while a ROM Builder task is running.")
    if not isinstance(text, str) or not text or len(text) > 4096 or "\x00" in text:
        raise ValueError("Terminal input must contain 1–4096 characters and no NUL bytes.")
    STATE_ROOT.mkdir(parents=True, exist_ok=True)
    input_path = STATE_ROOT / f"{job_id}.stdin"
    with input_path.open("a", encoding="utf-8", errors="replace") as queued:
        queued.write(text)
        if not text.endswith("\n"):
            queued.write("\n")
        queued.flush()
    append_log(job_id, f"\n[terminal input sent at {now()}]\n")
    return {"ok": True, "id": job_id}

def run_job(job_id: str, action: str, payload: dict[str, Any]) -> None:
    state = read_state(job_id)
    try:
        env, rom_path = build_environment(payload)
        if action == "clean":
            env["USER_CLEAN"] = "true"
        script_rel = ALLOWED_ACTIONS[action]
        script = (ROOT / script_rel).resolve()
        if not script.is_file() or ROOT not in script.parents:
            raise ValueError("The requested ROM Builder script is not available.")
        state.update(status="running", started_at=now(), pid=None, message=f"Running {action}")
        write_state(state)
        append_log(job_id, f"[{now()}] Action: {action}\nROM source: {rom_path}\nWorking directory: {rom_path if action == 'build' else ROOT}\nScript: {script_rel}\n\n")
        with (STATE_ROOT / f"{job_id}.log").open("a", encoding="utf-8", errors="replace") as log:
            # Android build scripts expect to execute inside the checked-out ROM
            # source tree: build/envsetup.sh, lunch and brunch are relative to it.
            # Non-build helper actions retain the addon root as their working dir.
            action_cwd = rom_path if action == "build" else ROOT
            proc = subprocess.Popen(
                ["bash", str(script)],
                cwd=str(action_cwd),
                env=env,
                stdin=subprocess.PIPE,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
                close_fds=True,
            )
            state["pid"] = proc.pid
            write_state(state)

            def forward_terminal_input() -> None:
                input_path = STATE_ROOT / f"{job_id}.stdin"
                offset = 0
                while proc.poll() is None:
                    try:
                        with input_path.open("rb") as queued:
                            queued.seek(offset)
                            chunk = queued.read(4096)
                        if chunk and proc.stdin:
                            proc.stdin.write(chunk)
                            proc.stdin.flush()
                            offset += len(chunk)
                    except FileNotFoundError:
                        pass
                    except (BrokenPipeError, OSError, ValueError):
                        break
                    time.sleep(0.15)
                try:
                    if proc.stdin and not proc.stdin.closed:
                        proc.stdin.close()
                except OSError:
                    pass

            input_thread = threading.Thread(target=forward_terminal_input, daemon=True)
            input_thread.start()
            code = proc.wait()
            input_thread.join(timeout=0.5)
        state = read_state(job_id)
        if state.get("status") == "cancelled":
            state.update(pid=None, worker_pid=None)
            write_state(state)
            return
        state.update(
            status="succeeded" if code == 0 else "failed",
            exit_code=code,
            finished_at=now(),
            message="Completed successfully." if code == 0 else f"Script exited with code {code}.",
            pid=None,
            worker_pid=None,
        )
        append_log(job_id, f"\n[{now()}] Finished with exit code {code}.\n")
        write_state(state)
    except Exception as exc:
        state = read_state(job_id)
        state.update(status="failed", message=str(exc), finished_at=now(), pid=None, exit_code=1)
        append_log(job_id, f"\n[{now()}] ERROR: {exc}\n")
        write_state(state)

def start_job(action: str, payload: dict[str, Any]) -> dict[str, Any]:
    if action not in ALLOWED_ACTIONS:
        raise ValueError("Unsupported ROM Builder action.")
    # Validate before creating a job so bad requests never start a process.
    _, source_path = build_environment(payload)
    if action == "build" and not (source_path / "build" / "envsetup.sh").is_file():
        raise ValueError("Android source tree is missing build/envsetup.sh. Sync or initialize a complete Android source tree before building.")
    STATE_ROOT.mkdir(parents=True, exist_ok=True)
    for existing in STATE_ROOT.glob("*.json"):
        try:
            previous = json.loads(existing.read_text(encoding="utf-8"))
            if previous.get("status") in {"queued", "running"}:
                raise ValueError("Another ROM Builder task is already running. Wait for it to finish or cancel it first.")
        except json.JSONDecodeError:
            continue
    job_id = str(uuid.uuid4())
    state = {
        "id": job_id, "action": action, "status": "queued",
        "created_at": now(), "started_at": None, "finished_at": None,
        "exit_code": None, "pid": None, "message": "Queued",
    }
    write_state(state)
    worker_payload = json.dumps(payload, separators=(",", ":"))
    worker = subprocess.Popen(
        [sys.executable, "-S", str(Path(__file__).resolve()), "worker",
         "--job-id", job_id, "--action", action, "--payload", worker_payload],
        cwd=str(ROOT),
        env={**os.environ, "ATEAM_ROM_BUILDER_STATE": str(STATE_ROOT)},
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
        close_fds=True,
    )
    latest = read_state(job_id)
    latest["worker_pid"] = worker.pid
    write_state(latest)
    return latest

def command_main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("devices")
    sub.add_parser("hosts")
    sub.add_parser("commands")
    sub.add_parser("config")
    start = sub.add_parser("start")
    start.add_argument("--action", required=True)
    start.add_argument("--payload", required=True, help="JSON encoded request")
    status = sub.add_parser("status")
    status.add_argument("--job-id", required=True)
    sub.add_parser("list", help="List persisted ROM Builder jobs for Agent context")
    sub.add_parser("shutdown", help="Stop active ROM Builder jobs started by this app")
    logs = sub.add_parser("logs")
    logs.add_argument("--job-id", required=True)
    logs.add_argument("--offset", type=int, default=0)
    cancel = sub.add_parser("cancel")
    cancel.add_argument("--job-id", required=True)
    terminal_input = sub.add_parser("input")
    terminal_input.add_argument("--job-id", required=True)
    terminal_input.add_argument("--text", required=True)
    worker = sub.add_parser("worker")
    worker.add_argument("--job-id", required=True)
    worker.add_argument("--action", required=True)
    worker.add_argument("--payload", required=True)
    args = parser.parse_args()
    try:
        if args.command == "devices":
            emit({"devices": devices()})
        elif args.command == "hosts":
            emit({"hosts": hosts()})
        elif args.command == "commands":
            emit({"commands": build_commands()})
        elif args.command == "config":
            emit({"rom_config": config_value(CONFIG_ROOT / "rom.conf"), "devices": devices(), "hosts": hosts(), "commands": build_commands()})
        elif args.command == "start":
            payload = json.loads(args.payload)
            if not isinstance(payload, dict):
                raise ValueError("Request payload must be a JSON object.")
            emit(start_job(args.action, payload))
        elif args.command == "status":
            emit(read_state(args.job_id))
        elif args.command == "list":
            jobs = []
            STATE_ROOT.mkdir(parents=True, exist_ok=True)
            for item in sorted(STATE_ROOT.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
                try:
                    state = json.loads(item.read_text(encoding="utf-8"))
                    if isinstance(state, dict) and "id" in state: jobs.append(state)
                except (OSError, json.JSONDecodeError): pass
            emit({"jobs": jobs[:20], "active": next((j for j in jobs if j.get("status") in {"queued", "running"}), None)})
        elif args.command == "shutdown":
            stopped = []
            STATE_ROOT.mkdir(parents=True, exist_ok=True)
            for item in STATE_ROOT.glob("*.json"):
                try: state = json.loads(item.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError): continue
                pid = state.get("pid") or state.get("worker_pid")
                if state.get("status") not in {"queued", "running"}: continue
                if pid:
                    try: os.killpg(int(pid), 15)
                    except ProcessLookupError: pass
                    except (PermissionError, ValueError):
                        try: os.kill(int(pid), 15)
                        except (ProcessLookupError, PermissionError, ValueError): pass
                state.update(status="cancelled", message="Stopped because A-Team Agent closed.", finished_at=now(), pid=None)
                write_state(state); append_log(state["id"], f"\n[{now()}] App shutdown requested; task stopped.\n"); stopped.append(state["id"])
            emit({"ok": True, "stopped": stopped})
        elif args.command == "logs":
            state_path(args.job_id)
            log_path = STATE_ROOT / f"{args.job_id}.log"
            content = log_path.read_text(encoding="utf-8", errors="replace") if log_path.exists() else ""
            offset = max(0, args.offset)
            emit({"text": content[offset:], "next_offset": len(content), "status": read_state(args.job_id)["status"]})
        elif args.command == "worker":
            payload = json.loads(args.payload)
            run_job(args.job_id, args.action, payload)
            emit(read_state(args.job_id))
        elif args.command == "cancel":
            state = read_state(args.job_id)
            pid = state.get("pid")
            if state.get("status") not in {"queued", "running"} or not pid:
                raise ValueError("This job is not currently running.")
            try:
                os.killpg(int(pid), 15)
            except ProcessLookupError:
                pass
            state.update(status="cancelled", message="Cancelled by user.", finished_at=now(), pid=None)
            write_state(state)
            append_log(args.job_id, f"\n[{now()}] Cancel requested by user.\n")
            emit(state)
        return 0
    except Exception as exc:
        emit({"error": str(exc)})
        return 2

if __name__ == "__main__":
    raise SystemExit(command_main())
