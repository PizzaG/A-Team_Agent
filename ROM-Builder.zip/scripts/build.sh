#!/bin/bash
#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_OPTIONS_DIR="$SCRIPT_DIR/build_options"
DEVICE_MODEL="$DEVICE_MODEL_NUMBER"
ROM_OUT_DIR="$ROM_PATH/out/target/product/$DEVICE_CODENAME"
export BUILD_OPTIONS_DIR

# Always enter the selected Android checkout before using source-tree-relative paths.
if [[ -z "${ROM_PATH:-}" || ! -d "$ROM_PATH" ]]; then
    echo "ERROR: ROM_PATH must point to the Android source checkout."
    exit 2
fi
cd "$ROM_PATH" || exit 2
if [[ ! -f "build/envsetup.sh" ]]; then
    echo "ERROR: $ROM_PATH is not a valid Android source checkout (build/envsetup.sh is missing)."
    exit 2
fi

clear
#clear

# Used For Testing variable additions
#env | sort | grep -E 'DEVICE|ROM|ANDROID|JOB|CCACHE'

# Vanilla - No Gapps Zip Naming
if [[ "$GAPPS_VARIANT" == "vanilla" ]]; then
    GAPPS=VANILLA
fi
# Gapps Zip Naming
if [[ "$GAPPS_VARIANT" == "gapps" ]]; then
    GAPPS=GAPPS
fi
# Micro-G Gapps Zip Naming
if [[ "$GAPPS_VARIANT" == "micro-g" ]]; then
    GAPPS=MICROG
fi
# Foss Gapps Zip Naming
if [[ "$GAPPS_VARIANT" == "foss" ]]; then
    GAPPS=FOSS
fi
ROM_FINAL_ZIP_NAME="$ROM_DISPLAY_NAME-$ROM_MAJOR_VERSION.$ROM_MINOR_VERSION-UNOFFICIAL-$GAPPS-$DEVICE_DISPLAY_CODENAME-$DEVICE_MODEL_NUMBER.zip"
if [[ "$USE_CCACHE" == "1" ]]; then
    CCACHE=Yes
else
    CCACHE=No
fi
if [[ "$APN_VARIANT" == "1" ]]; then
    APN=Custom
else
    APN=Default
fi

echo 
echo "================================"
echo "ROM Build Settings ..."
echo 
echo "Device: $DEVICE_DISPLAY_NAME"
echo "Device Codename: $DEVICE_DISPLAY_CODENAME"
echo "Device Model: $DEVICE_MODEL"
echo "Rom: $ROM_DISPLAY_NAME"
echo "Android: $ANDROID_VERSION"
echo "Build Jobs: $BUILD_JOBS"
echo "Ccache: $CCACHE"
echo "Ccache Size: ${CCACHE_SIZE}GB"
echo "APN Variant: $APN"
echo "Build Variant: ${BUILD_VARIANT^}"
echo "Gapps Variant: ${GAPPS_VARIANT^}"
echo "Installer Variant: ${INSTALLER_VARIANT^}"
echo "Pre-Build Clean Variant: ${CLEAN_VARIANT^}"
echo "================================"
echo 
echo 
sleep 5
echo "ROM Build Starting ..."
echo 
echo
# Source the Android build environment from the selected source tree.
source "$ROM_PATH/build/envsetup.sh"
# Configure APN selection on every build. Missing optional A-Team APN assets
# should warn and continue when the source checkout does not include them.
echo "Configuring APN Selection ..."
bash "$BUILD_OPTIONS_DIR/apn.sh"
echo
# Export Build Variables
export LC_ALL=C
export SELINUX_IGNORE_NEVERALLOWS=true
# Set Ccache Option
bash "$BUILD_OPTIONS_DIR/ccache.sh"
# Default Rom Installer
if [[ $INSTALLER_VARIANT == "default" ]]; then
   # Setup Installer Options
   source "$BUILD_OPTIONS_DIR/default_installer_build.sh"
   # Setup Lunch & Build
   #source "$BUILD_OPTIONS_DIR/rom_build_commands.sh"
   # Lunch Command
   #eval $LUNCH_COMMAND
   # Setup Clean Options & lunch & build command
   source "$SCRIPT_DIR/clean.sh"
   # Lunch Command
   eval "$LUNCH_COMMAND"
   # Clean
   eval "$CLEAN_COMMAND"
   # Rom Build Command
   eval "$ROM_BUILD_COMMAND"
   #
   # Sanity Check For ROM Build
   #
   echo "================================"
   echo "Checking For Finished ROM ..."
   echo "================================"
   echo
   echo "ROM Output Directory:"
   echo "$ROM_OUT_DIR"
   echo
   echo "ROM Search Pattern:"
   echo "$ROM_BUILD_ZIP_NAME"
   echo
   #
   # Find ROM ZIP matching the configured pattern.
   #
   ROM_MATCHES=(
       "$ROM_OUT_DIR"/$ROM_BUILD_ZIP_NAME
   )
   #
   # If the glob did not match anything,
   # Bash leaves the pattern untouched.
   #
   if [[ ! -f "${ROM_MATCHES[0]}" ]]; then
       ROM_MATCHES=()
   fi
   #
   # Exactly one ROM should have been produced.
   #
   if [[ ${#ROM_MATCHES[@]} -eq 1 ]]; then
       ROM_FINAL_ZIP="${ROM_MATCHES[0]}"
       ROM_FINAL_NAME="$(basename "$ROM_FINAL_ZIP")"
       echo "ROM Build Found:"
       echo "$ROM_FINAL_NAME"
       echo
       # ROM_FINAL_LOCATION may contain $HOME.  It is exported by the
       # builder without quoting that variable so the shell on the actual
       # build host expands it.  This therefore resolves locally on Local
       # builds and against the SSH user's HOME on SSH builds.
       echo "Moving ROM To Final Location:"
       echo "$ROM_FINAL_LOCATION/$DEVICE_DISPLAY_CODENAME/"
       echo
       #
       # Create final device directory if necessary.
       #
       mkdir -p "$ROM_FINAL_LOCATION/$DEVICE_DISPLAY_CODENAME"
       #
       # Move completed ROM.
       #
       if mv "$ROM_FINAL_ZIP" \
           "$ROM_FINAL_LOCATION/$DEVICE_DISPLAY_CODENAME/"; then
           mv $ROM_FINAL_LOCATION/$DEVICE_DISPLAY_CODENAME/$ROM_FINAL_NAME $ROM_FINAL_LOCATION/$DEVICE_DISPLAY_CODENAME/$ROM_FINAL_ZIP_NAME
           echo "================================"
           echo "ROM Successfully Moved & Renamed!"
           echo "================================"
           echo
           echo "$ROM_FINAL_LOCATION/$DEVICE_DISPLAY_CODENAME/$ROM_FINAL_ZIP_NAME"
           echo
       else
           echo "================================"
           echo "ERROR: Failed To Move ROM!"
           echo "================================"
           echo
           exit 1
       fi
   elif [[ ${#ROM_MATCHES[@]} -gt 1 ]]; then
       echo "================================"
       echo "ERROR: Multiple ROM ZIPs Found!"
       echo "================================"
       echo
       for ROM_FILE in "${ROM_MATCHES[@]}"; do
           echo "  $(basename "$ROM_FILE")"
       done
       echo
       echo "Refusing To Guess Which ROM To Move."
       echo
       exit 1
   else
       echo "================================"
       echo "ERROR: Finished ROM Not Found!"
       echo "================================"
       echo
       echo "Expected Pattern:"
       echo "$ROM_OUT_DIR/$ROM_BUILD_ZIP_NAME"
       echo
       echo "ZIP Files Currently In Output Directory:"
       echo
       find "$ROM_OUT_DIR" \
           -maxdepth 1 \
           -type f \
           -name "*.zip" \
           -printf "  %f\n" \
           2>/dev/null
       exit 1
   fi

# A-Team Rom Installer
elif [[ $INSTALLER_VARIANT == "custom" ]]; then
   bash "$BUILD_OPTIONS_DIR/custom_installer_build.sh"
   # Lunch
   #lunch ${ROM_BUILD_NAME}_${DEVICE_NAME}-${ROM_TARGET_RELEASE}-${BUILD_VARIANT}
   # Build
   #"$ROM_CUSTOM_BUILD_COMMAND" "$DEVICE_CODENAME"
fi
#m bacon -j$JOBS


