#!/bin/bash
#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_OPTIONS_DIR="$SCRIPT_DIR/build_options"

source "$BUILD_OPTIONS_DIR/rom_build_commands.sh"
if [ "$CLEAN_VARIANT" = "full" ]; then
    export CLEAN_COMMAND="$M clean"
elif [ "$CLEAN_VARIANT" = "lite" ]; then
    export CLEAN_COMMAND="$M installclean"
elif [ "$CLEAN_VARIANT" = "none" ]; then
    echo "No Cleaning Selected ..."
fi

# cd to rom
if [ ! "$USER_CLEAN" = "true" ]; then
    cd "$ROM_PATH" || exit 1
    echo 
    echo "================================"
    echo "ROM Clean Settings ..."
    echo 
    echo "Pre-Build Clean Variant: ${CLEAN_VARIANT^}"
    echo "================================"
    echo 
    echo 
    sleep 5
    echo "Pre-Build Rom Clean Starting ..."
    echo 
    echo
fi

# Run user selected clean button
if [ "$USER_CLEAN" = "true" ]; then
    clear
    echo 
    echo "================================"
    echo "ROM Clean Settings ..."
    echo 
    echo "Pre-Build Clean Variant: ${CLEAN_VARIANT^}"
    echo "================================"
    echo 
    echo 
    sleep 5
    echo "Pre-Build Rom Clean Starting ..."
    echo 
    echo
    cd "$ROM_PATH" || exit 1
    if [ "$CLEAN_VARIANT" = "none" ]; then
        echo "No Cleaning Selected ..."
    else
        # Source Build Env
        source "build/envsetup.sh"
        # Lunch
        eval "$LUNCH_COMMAND"
        # Clean
        eval "$CLEAN_COMMAND"
    fi
fi
