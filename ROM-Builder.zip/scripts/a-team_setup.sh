#!/bin/bash

#
# Copyright 2019-Present A-Team Digital Solutions
#
# A-Team Setup Script
#

SETUP_VERSION="1.02"
SETUP_DATE="8-15-2026"

# Date
date=$(date -u +%-m/%d/%Y)

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_OPTIONS_DIR="$SCRIPT_DIR/build_options"
export BUILD_OPTIONS_DIR

echo "A-Team Setup Script" 
    
# Copyright & Current Date Stamp
echo 
echo "Copyright 2019-Present A-Team Digital Solutions"
echo 
sleep 5

# Software Info
echo "Setup Version: $SETUP_VERSION"
echo
echo "Setup Update: $SETUP_DATE"
echo  
echo "Current Date: $date" 
echo 
sleep 5

# Ensure Final Package Directory Location Exists
echo "Creating Final Rom Directory Location ..."
mkdir $ROM_FINAL_LOCATION/$DEVICE_DISPLAY_CODENAME >/dev/null 2>&1
echo 
echo "1/1 ..."
echo 
echo "ROM Final Location: $ROM_FINAL_LOCATION/$DEVICE_DISPLAY_CODENAME"
echo 
sleep 3

# Copy A-Team Package to rom
echo "Copying A-Team Addon Package To ROM ..."
mkdir $ROM_PATH/device/A-Team
cp -r $A_TEAM_SETUP_LOCATION/A-Team $ROM_PATH/device/A-Team/A-Team
cp -r $A_TEAM_SETUP_LOCATION/Apps $ROM_PATH/device/A-Team
cp -r $A_TEAM_SETUP_LOCATION/Busybox $ROM_PATH/device/A-Team
cp -r $A_TEAM_SETUP_LOCATION/init $ROM_PATH/device/A-Team
cp -r $A_TEAM_SETUP_LOCATION/Prerequisites $ROM_PATH/device/A-Team
cp -r $A_TEAM_SETUP_LOCATION/scripts $ROM_PATH/device/A-Team
cp -r $A_TEAM_SETUP_LOCATION/wallpapers $ROM_PATH/device/A-Team
cp -r $A_TEAM_SETUP_LOCATION/A-Team.mk $ROM_PATH/device/A-Team
echo 
echo "1/1 ..."
sleep 3

# Setup APN Option
echo 
echo "2/2 ..."
echo
sleep 3
bash "$BUILD_OPTIONS_DIR/apn.sh"

# A-Team Internal System/Vendor Version Mismatch Error Patch Check
echo "Checking If Rom Needs Internal System/Vendor Version Mismatch Error Patch ..."
echo 
if [ -f $ROM_PATH/frameworks/base/core/java/android/os/Build.java.orig ]; then
   echo "A-Team Patch 1 Already Applied, Skipping ..."
   echo 
   sleep 3
else
   echo "Rom Needs Internal System/Vendor Version Mismatch Error Patch, Patching ..."
   patch -u -b $ROM_PATH/frameworks/base/core/java/android/os/Build.java -i ~/Desktop/A-Team/patches/Build.java.patch >/dev/null 2>&1
   echo 
   echo "1/1 ..."
   sleep 3
   echo 
   # Sanity Check
   if [ -f $ROM_PATH/frameworks/base/core/java/android/os/Build.java.rej ]; then
      echo "Patch Failed, Trying Alternate Patch File ..."
      rm -rf $ROM_PATH/frameworks/base/core/java/android/os/Build.java
      rm -rf $ROM_PATH/frameworks/base/core/java/android/os/Build.java.rej
      mv $ROM_PATH/frameworks/base/core/java/android/os/Build.java.orig $ROM_PATH/frameworks/base/core/java/android/os/Build.java
      patch -u -b $ROM_PATH/frameworks/base/core/java/android/os/Build.java -i ~/Desktop/A-Team/patches/Build.java-alt.patch >/dev/null 2>&1
      echo 
   fi
   if [ -f $ROM_PATH/frameworks/base/core/java/android/os/Build.java.rej ]; then
      echo "Patch Failed, Trying Alternate Patch 1 File ..."
      rm -rf $ROM_PATH/frameworks/base/core/java/android/os/Build.java
      rm -rf $ROM_PATH/frameworks/base/core/java/android/os/Build.java.rej
      mv $ROM_PATH/frameworks/base/core/java/android/os/Build.java.orig $ROM_PATH/frameworks/base/core/java/android/os/Build.java
      patch -u -b frameworks/base/core/java/android/os/Build.java -i ~/Desktop/A-Team/patches/Build.java-alt-1.patch >/dev/null 2>&1
      echo 
   fi
   if [ -f $ROM_PATH/frameworks/base/core/java/android/os/Build.java.rej ]; then
      echo "Patch Failed, Trying Alternate Patch 2 File ..."
      rm -rf $ROM_PATH/frameworks/base/core/java/android/os/Build.java
      rm -rf $ROM_PATH/frameworks/base/core/java/android/os/Build.java.rej
      mv $ROM_PATH/frameworks/base/core/java/android/os/Build.java.orig $ROM_PATH/frameworks/base/core/java/android/os/Build.java
      patch -u -b frameworks/base/core/java/android/os/Build.java -i ~/Desktop/A-Team/patches/Build.java-alt-2.patch >/dev/null 2>&1
      echo 
   fi
   if [ -f $ROM_PATH/frameworks/base/core/java/android/os/Build.java.rej ]; then
      echo "Patch Failed, Trying Alternate Patch 3 File ..."
      rm -rf $ROM_PATH/frameworks/base/core/java/android/os/Build.java
      rm -rf $ROM_PATH/frameworks/base/core/java/android/os/Build.java.rej
      mv $ROM_PATH/frameworks/base/core/java/android/os/Build.java.orig $ROM_PATH/frameworks/base/core/java/android/os/Build.java
      patch -u -b $ROM_PATH/frameworks/base/core/java/android/os/Build.java -i ~/Desktop/A-Team/patches/Build.java-alt-3.patch >/dev/null 2>&1
      echo 
   fi
   if [ -f $ROM_PATH/frameworks/base/core/java/android/os/Build.java.rej ]; then
      echo "Patch Failed, Trying Alternate Patch 4 File ..."
      rm -rf $ROM_PATH/frameworks/base/core/java/android/os/Build.java
      rm -rf $ROM_PATH/frameworks/base/core/java/android/os/Build.java.rej
      mv $ROM_PATH/frameworks/base/core/java/android/os/Build.java.orig $ROM_PATH/frameworks/base/core/java/android/os/Build.java
      patch -u -b $ROM_PATH/frameworks/base/core/java/android/os/Build.java -i ~/Desktop/A-Team/patches/Build.java-alt-4.patch >/dev/null 2>&1
      echo 
   fi
   if [ -f $ROM_PATH/frameworks/base/core/java/android/os/Build.java.rej ]; then
      echo "FAILED, Please Read --> README-VersionMismatchFix.txt ..."
      echo 
      gnome-terminal -- bash -c "cat $A_TEAM_SETUP_LOCATION/README-VersionMismatchFix.txt; exec bash"
      echo 
      echo "PRESS ENTER TO CONTINUE"
      read
   fi
fi

# Check If Rom Uses Changelog & Hijack It If So For Custom Changelogs
if [ -f $ROM_PATH/vendor/$ROM_VENDOR_NAME/tools/changelog ]; then
   mkdir $ROM_PATH/A-Team_Changelog
   echo "Rom Changelog Found, Hijacking For Custom Changelog Ability ..."
   echo 
   # Backup Original
   echo "Backing Up Original Changelog ..."
   mv $ROM_PATH/vendor/$ROM_VENDOR_NAME/tools/changelog $ROM_PATH/vendor/$ROM_VENDOR_NAME/tools/changelog.bak
   echo 
   echo "1/1 ..."
   echo 
   sleep 3
   # Copy Modded
   echo "Copying Modified Changelog ..."
   cp -r $A_TEAM_SETUP_LOCATION/Changelog/changelog $ROM_PATH/vendor/$ROM_VENDOR_NAME/tools
   echo 
   echo "1/1 ..."
   echo 
   sleep 3
elif [ -f $ROM_PATH/vendor/$ROM_VENDOR_NAME/tools/changelog.sh ]; then
   mkdir $ROM_PATH/A-Team_Changelog
   echo "Rom changelog.sh Found, Hijacking For Custom Changelog Ability ..."
   echo ""
   # Backup Original
   echo "Backing Up Original changelog.sh ..."
   mv $ROM_PATH/vendor/$ROM_VENDOR_NAME/tools/changelog.sh $ROM_PATH/vendor/$ROM_VENDOR_NAME/tools/changelog.sh.bak
   echo 
   echo "1/ 1 ..."
   echo
   sleep 3
   # Copy Modded
   echo "Copying Modified changelog.sh ..."
   cp -r $A_TEAM_SETUP_LOCATION/Changelog/changelog.sh $ROM_PATH/vendor/$ROM_VENDOR_NAME/tools
   echo 
   echo "1/1 ..."
   echo 
   sleep 3
elif [ -f $ROM_PATH/vendor/$ROM_VENDOR_NAME/build/tools/changelog.sh ]; then
   mkdir $ROM_PATH/A-Team_Changelog
   echo "Rom changelog.sh Found, Hijacking For Custom Changelog Ability ..."
   echo ""
   # Backup Original
   echo "Backing Up Original changelog.sh ..."
   mv $ROM_PATH/vendor/$ROM_VENDOR_NAME/build/tools/changelog.sh $ROM_PATH/vendor/$ROM_VENDOR_NAME/build/tools/changelog.sh.bak
   echo 
   echo "1/1 ..."
   echo 
   sleep 3
   # Copy Modded
   echo "Copying Modified changelog.sh ..."
   cp -r $A_TEAM_SETUP_LOCATION/Changelog/changelog.sh $ROM_PATH/vendor/$ROM_VENDOR_NAME/build/tools
   echo 
   echo "1/1 ..."
   echo 
   sleep 3
fi

# A-Team GSI Setup
#echo "Moving GSI Device Tree Into Place..."
#echo ""
#rm -rf device/generic
#cp -r $A_TEAM_PACKAGE_LOCATION/device/generic device/generic

# 1
#if [ -f vendor/$ROM_VENDOR_NAME/build/target/product/lineage_generic_target.mk ]; then
#echo "lineage_generic_target.mk Found, Replacing..."
#rm -rf vendor/$ROM_VENDOR_NAME/build/target/product/lineage_generic_target.mk
#cp -r $A_TEAM_PACKAGE_LOCATION/device/gsi/lineage_generic_target.mk vendor/$ROM_VENDOR_NAME/build/target/product
#else
#echo "lineage_generic_target.mk Not Found, Adding..."
#echo "Modify Android.mk In: vendor/$ROM_VENDOR_NAME/build/target/product..."
#fi

# 2
#if [ -f vendor/$ROM_VENDOR_NAME/build/target/product/lineage_generic_tv_target.mk ]; then
#echo "lineage_generic_tv_target.mk Found, Replacing..."
#rm -rf vendor/$ROM_VENDOR_NAME/build/target/product/lineage_generic_tv_target.mk
#cp -r $A_TEAM_PACKAGE_LOCATION/device/gsi/lineage_generic_tv_target.mk vendor/$ROM_VENDOR_NAME/build/target/product
#else
#echo "lineage_generic_tv_target.mk Not Found, Adding..."
#echo "Modify Android.mk In: vendor/$ROM_VENDOR_NAME/build/target/product..."
#fi

# 3
#if [ -f vendor/$ROM_VENDOR_NAME/build/target/product/lineage_gsi_arm.mk ]; then
#echo "lineage_gsi_arm.mk Found, Replacing..."
#rm -rf vendor/$ROM_VENDOR_NAME/build/target/product/lineage_gsi_arm.mk
#cp -r $A_TEAM_PACKAGE_LOCATION/device/gsi/lineage_gsi_arm.mk vendor/$ROM_VENDOR_NAME/build/target/product
#else
#echo "lineage_gsi_arm.mk Not Found, Adding..."
#echo "Modify Android.mk In: vendor/$ROM_VENDOR_NAME/build/target/product..."
#fi

# 4
#if [ -f vendor/$ROM_VENDOR_NAME/build/target/product/lineage_gsi_arm64.mk ]; then
#echo "lineage_gsi_arm64.mk Found, Replacing..."
#rm -rf vendor/$ROM_VENDOR_NAME/build/target/product/lineage_gsi_arm64.mk
#cp -r $A_TEAM_PACKAGE_LOCATION/device/gsi/lineage_gsi_arm64.mk vendor/$ROM_VENDOR_NAME/build/target/product
#else
#echo "lineage_gsi_arm64.mk Not Found, Adding..."
#echo "Modify Android.mk In: vendor/$ROM_VENDOR_NAME/build/target/product..."
#fi

# 5
#if [ -f vendor/$ROM_VENDOR_NAME/build/target/product/lineage_gsi_tv_arm.mk ]; then
#echo "lineage_gsi_tv_arm.mk Found, Replacing..."
#rm -rf vendor/$ROM_VENDOR_NAME/build/target/product/lineage_gsi_tv_arm.mk
#cp -r $A_TEAM_PACKAGE_LOCATION/device/gsi/lineage_gsi_tv_arm.mk vendor/$ROM_VENDOR_NAME/build/target/product
#else
#echo "lineage_gsi_tv_arm.mk Not Found, Adding..."
#echo "Modify Android.mk In: vendor/$ROM_VENDOR_NAME/build/target/product..."
#fi

# 6
#if [ -f vendor/$ROM_VENDOR_NAME/build/target/product/lineage_gsi_tv_arm64.mk ]; then
#echo "lineage_gsi_tv_arm64.mk Found, Replacing..."
#rm -rf vendor/$ROM_VENDOR_NAME/build/target/product/lineage_gsi_tv_arm64.mk
#cp -r $A_TEAM_PACKAGE_LOCATION/device/gsi/lineage_gsi_tv_arm64.mk vendor/$ROM_VENDOR_NAME/build/target/product
#else
#echo "lineage_gsi_tv_arm64.mk Not Found, Adding..."
#echo "Modify Android.mk In: vendor/$ROM_VENDOR_NAME/build/target/product..."
#fi

# 7
#if [ -f build/make/target/product/generic_system.mk ]; then
#echo "generic_system.mk Found, Replacing..."
#echo ""
#rm -rf build/make/target/product/generic_system.mk
#cp -r $A_TEAM_PACKAGE_LOCATION/device/gsi/generic_system.mk build/make/target/product
#else
#echo "generic_system.mk Not Found, Adding..."
#echo ""
#echo "Modify Android.mk In: build/make/target/product..."
#fi

# 8
#if [ -f build/make/target/product/generic_system_arm64.mk ]; then
#echo "generic_system_arm64.mk Found, Replacing..."
#rm -rf build/make/target/product/generic_system_arm64.mk
#cp -r $A_TEAM_PACKAGE_LOCATION/device/gsi/generic_system_arm64.mk build/make/target/product
#else
#echo "generic_system_arm64.mk Not Found, Adding..."
#echo "Modify Android.mk In: build/make/target/product..."
#fi

# 9
#if [ -f build/make/target/product/gsi_release.mk ]; then
#echo "gsi_release.mk Found, Replacing..."
#rm -rf build/make/target/product/gsi_release.mk
#cp -r $A_TEAM_PACKAGE_LOCATION/device/gsi/gsi_release.mk build/make/target/product
#else
#echo "gsi_release.mk Not Found, Adding..."
#echo "Modify Android.mk In: build/make/target/product..."
#fi

# 10
#if [ -f build/make/target/product/generic.mk ]; then
#echo "generic.mk Found, Replacing..."
#rm -rf build/make/target/product/generic.mk
#cp -r $A_TEAM_PACKAGE_LOCATION/device/gsi/generic.mk build/make/target/product
#else
#echo "generic.mk Not Found, Adding..."
#echo "Modify Android.mk In: build/make/target/product..."
#fi
 
echo "A-Team Setup Complete, Please Enjoy!!"
echo
