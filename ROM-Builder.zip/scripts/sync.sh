#!/bin/bash
#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(realpath "${SCRIPT_DIR}/..")"
CONFIG_DIR="${PROJECT_ROOT}/configs"
DEVICE_CONFIG="${CONFIG_DIR}/devices/${DEVICE_NAME}.conf"
A_TEAM_SETUP="${SCRIPT_DIR}/a-team_setup.sh"
A_TEAM_SETUP_CHECK="${ROM_PATH}/device/A-Team/A-Team-Setup.check"

if [ ! -f "$DEVICE_CONFIG" ]; then
    echo
    echo "Device Config Not Found: $DEVICE_CONFIG"
    exit 1
fi
# A-Team Setup
# Resolve the addon location on the machine actually running this script.
# For SSH builds this makes A-Team live on the remote host rather than the
# GUI/builder's local machine.  The shell's HOME is authoritative here.
A_TEAM_SETUP_LOCATION="${HOME}/Desktop/A-Team"
export A_TEAM_SETUP_LOCATION

if [ -f "$A_TEAM_SETUP_CHECK" ]; then
    clear
    echo
    echo "A-Team Setup Already Run, Skipping Setup ..."
else
    clear
    echo
    echo "Syncing A-Team Addon Package ..."
    if [ -d "$A_TEAM_SETUP_LOCATION" ]; then
        echo
        7z a -mx=9 "${A_TEAM_SETUP_LOCATION}-BACKUP.7z" "$A_TEAM_SETUP_LOCATION"
        echo
        rm -rf $A_TEAM_SETUP_LOCATION
    fi
    git clone https://ateam.gotadell.com/git/PizzaG/android_device_A-Team.git $A_TEAM_SETUP_LOCATION
    echo 
    echo
    echo "Running A-Team Setup ..."
    echo
    if bash "$A_TEAM_SETUP"; then
        mkdir -p "$(dirname "$A_TEAM_SETUP_CHECK")"
        touch "$A_TEAM_SETUP_CHECK"
    else
        echo "A-Team Setup Failed!"
        exit 1
    fi
fi

SYNC="${SCRIPT_DIR}/devices_sync/${DEVICE_SYNC_SCRIPT}"

cd "$ROM_PATH" || exit 1
if [ -f "$SYNC" ]; then
    bash "$SYNC"
else
    echo "No Device Sync Script Found For: $DEVICE_DISPLAY_CODENAME"
fi
