#!/bin/bash
#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

# Rom - BlissROM
if [[ $BUILD_COMMAND == "blissrom" ]]; then
   LUNCH_COMMAND="lunch ${ROM_BUILD_NAME}_${DEVICE_NAME}-${ROM_TARGET_RELEASE}"
   export LUNCH_COMMAND
   # Bliss Gapps Selection
   if [[ $GAPPS_VARIANT == "gapps" ]]; then
      gapps="-g"
   elif [[ $GAPPS_VARIANT == "vanilla" ]]; then
      gapps="-v"
   fi  
   ROM_BUILD_COMMAND="blissify $gapps $DEVICE_CODENAME"
   export ROM_BUILD_COMMAND   

# Rom - Derpfest
elif [[ $BUILD_COMMAND == "derpfest" ]]; then
   LUNCH_COMMAND="lunch ${ROM_BUILD_NAME}_${DEVICE_NAME}-${ROM_TARGET_RELEASE}-${BUILD_VARIANT}"
   ROM_BUILD_COMMAND="m derp"
   export LUNCH_COMMAND
   export ROM_BUILD_COMMAND

# Rom - Lineage
elif [[ $BUILD_COMMAND == "lineage" ]]; then
   LUNCH_COMMAND="lunch ${ROM_BUILD_NAME}_${DEVICE_NAME}-${ROM_TARGET_RELEASE}-${BUILD_VARIANT}"
   ROM_BUILD_COMMAND="brunch $DEVICE_CODENAME"
   export LUNCH_COMMAND
   export ROM_BUILD_COMMAND

# Default Rom Build Command from rom.conf
else
   LUNCH_COMMAND="lunch ${ROM_BUILD_NAME}_${DEVICE_NAME}-${ROM_TARGET_RELEASE}-${BUILD_VARIANT}"
   ROM_BUILD_COMMAND="$DEFAULT_ROM_BUILD_COMMAND"
   export LUNCH_COMMAND
   export ROM_BUILD_COMMAND

fi # LEAVE THIS !!


