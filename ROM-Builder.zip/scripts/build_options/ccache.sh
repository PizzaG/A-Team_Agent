#!/usr/bin/env bash
#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

# Export user selected ccache toggle
if [[ "$USE_CCACHE" == "1" ]]; then
    export USE_CCACHE=1
    export CCACHE_EXEC="$(command -v ccache)"
    export CCACHE_DIR="$HOME/.ccache"
    echo "CCache: Enabled"
    echo "  Binary : $CCACHE_EXEC"
    echo "  Cache  : $CCACHE_DIR"
    echo
    ccache -M ${CCACHE_SIZE}G
    ccache -s
    echo
    echo
else
    export USE_CCACHE=0
    echo "CCache: Disabled"
    echo
    echo
fi
