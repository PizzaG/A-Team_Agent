#!/usr/bin/env bash
#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

# Device Auto select since fogos spans 2 devices
if [[ "$DEVICE_DISPLAY_NAME" == "Moto G34 5G" ]]; then
    sed -i 's/PRODUCT_MODEL := moto g34 5G/PRODUCT_MODEL := Moto G34 5G/g' $ROM_PATH/device/motorola/${DEVICE_CODENAME}/lineage_${DEVICE_CODENAME}.mk
    echo "3/3 ..."
    echo 
    sleep 3
elif [[ "$DEVICE_DISPLAY_NAME" == "Moto G45 5G" ]]; then
    sed -i 's/PRODUCT_MODEL := moto g34 5G/PRODUCT_MODEL := Moto G45 5G/g' $ROM_PATH/device/motorola/${DEVICE_CODENAME}/lineage_${DEVICE_CODENAME}.mk
    echo "3/3 ..."
    echo 
    sleep 3
   # Device Auto select since rtwo spans 3 devices
elif [[ "$DEVICE_DISPLAY_NAME" == "Moto Edge 40 Pro" ]]; then
    sed -i 's/PRODUCT_MODEL := motorola edge 40 pro/PRODUCT_MODEL := Moto Edge 40 Pro/g' $ROM_PATH/device/motorola/${DEVICE_CODENAME}/lineage_${DEVICE_CODENAME}.mk
    echo "3/3 ..."
    echo 
    sleep 3
elif [[ "$DEVICE_DISPLAY_NAME" == "Moto X40" ]]; then
    sed -i 's/PRODUCT_MODEL := motorola edge 40 pro/PRODUCT_MODEL := Moto X40/g' $ROM_PATH/device/motorola/${DEVICE_CODENAME}/lineage_${DEVICE_CODENAME}.mk
    echo "3/3 ..."
    echo 
    sleep 3
elif [[ "$DEVICE_DISPLAY_NAME" == "Moto Edge+ 2023" ]]; then
    sed -i 's/PRODUCT_MODEL := motorola edge 40 pro/PRODUCT_MODEL := Moto Edge+ - 2023/g' $ROM_PATH/device/motorola/${DEVICE_CODENAME}/lineage_${DEVICE_CODENAME}.mk
    echo "3/3 ..."
    echo 
    sleep 3
fi
