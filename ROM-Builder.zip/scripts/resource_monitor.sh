#!/bin/bash
#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

export TERM=xterm-256color

# Check for btop or bpytop
if command -v btop &> /dev/null; then
    exec btop
    # Your code to run btop or log it
elif command -v bpytop &> /dev/null; then
    echo "bpytop Is Installed & Starting ..."
    sleep 5
    exec bpytop
    # Your code to run bpytop or log it
else
    echo "Neither btop Nor bpytop Was Found On This System, Please Install One."
    echo 
    echo "Install With:"
    echo "sudo apt install btop"
    echo "OR"
    echo "sudo apt install bpytop"
    echo
    read -n1 -r -p "Press Any Key..."
    # Optional fallback behavior (e.g., fallback to htop or top)
fi
