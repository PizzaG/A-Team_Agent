#
# Copyright (C) 2019-Present A-Team Digital Solutions
#

VERSION = 18
DISPLAY_VERSION = "1.2"
