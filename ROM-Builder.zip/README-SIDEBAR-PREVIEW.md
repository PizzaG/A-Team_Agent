# ROM Builder — A-Team Agent Add-on

The ROM Builder add-on provides an Agent-native workspace at `/workspace/rom-builder`
and a direct control CLI for the same visible UI.

## Agent GUI control contract

The Agent uses a read → set → press → observe → verify workflow:

```bash
python3 -S agent_cli.py spec
python3 -S agent_cli.py snapshot
python3 -S agent_cli.py control read --id device
python3 -S agent_cli.py control set --id device --value fogo
python3 -S agent_cli.py control press --id build
python3 -S agent_cli.py poll --job-id <job-id> --offset 0
```

- `spec` describes every form control, button, terminal action, output and
  supported command.
- `snapshot` returns current form state, validation, jobs, log tail, sensors and
  terminal sessions.
- `control read` reads one visible control/output or the full UI state.
- `control set` updates the same validated form state used by the web UI.
- `control press` activates the corresponding visible button.
- Legacy commands (`form-get`, `form-set`, `run`, `status`, `logs`, `keys`,
  `input`, `shell-start`, `shell-poll`, `shell-input`, `shell-stop`, `cancel`)
  remain supported.

The app UI and Agent CLI share the state directory selected by
`ATEAM_ROM_BUILDER_STATE`. In the A-Team sandbox this is mounted at
`/mnt/ateam-rom-builder-state`; do not use a separate state directory.

## Available actions

- Build ROM
- Sync source
- Sync GApps
- Clean
- A-Team setup
- Upload build

The CLI validates form values and source-tree structure before starting an
allow-listed action. Jobs have persistent IDs, status, exit codes, logs, and
cancellation. The interactive Build Console has its own persistent terminal
session ID and is independent from a background build job.

## Source tree access

For Agent-driven operations, keep the Android checkout under the shared
`A-Team-Agent_Workspace` directory, or ensure that the checkout is explicitly
mounted into the Agent runtime. The CLI maps host paths under
`~/A-Team-Agent_Workspace` to `/mnt/user-data/workspace`. The desktop UI may
browse other host paths, but those paths are not automatically visible inside
the Agent sandbox.

## Native GTK fallback

Run `bash launch-rom-builder.sh` on a Linux desktop with GTK 3, PyGObject, and
VTE 2.91 installed. The native GTK interface remains available as a fallback.
