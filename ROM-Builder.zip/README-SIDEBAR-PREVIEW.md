# ROM Builder in A-Team Agent

The Agent is the main application shell. The original GTK interface remains available as a fallback, while `/workspace/rom-builder` exposes the first Agent-native control surface.

## Agent-native controls

- Build configuration and known ROM build command selection.
- Validated local build, source sync, GApps sync, clean, setup, and upload actions.
- Persistent job status, live output polling, and cancellation.
- Device/host discovery and live host resource metrics.
- Application updates are managed by A-Team Agent; ROM Builder has no separate updater.

## Launching the fallback GTK interface

Run `bash launch-rom-builder.sh` on a Linux desktop with GTK 3, PyGObject, and VTE 2.91 installed. The native window is retained while the Agent-native UI is developed toward full feature parity.

The integrated control API only runs allow-listed scripts and validates device, source-tree path, variants, and build job count before starting a task. Remote SSH execution, interactive shell parity, project-profile persistence, and the original splash/icon tools are not yet ported into the Agent UI.
