"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Activity, Cpu, HardDrive, Layers3, Play, RefreshCw, Settings2, Square, TerminalSquare, Wrench, Monitor } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useI18n } from "@/core/i18n/hooks";

type Device = { name: string; display: string; codename: string };
type Job = { id: string; action: string; status: string; message?: string; exit_code?: number | null };
type Host = { name: string; kind: string; server_address?: string };
type BuildCommand = { id: string; label: string };
type ResourceSnapshot = {
  hostname: string; platform: string; cpuCount: number; loadAverage: number[];
  memory: { total: number; free: number; used: number };
  disk: { total: number; free: number } | null; sampledAt: string;
};


const ROM_BUILDER_ZH: Record<string, string> = {
  "A-Team Add-on Tools": "A-Team 插件工具", "ROM Builder": "ROM 构建器",
  "Configure a build, run the existing ROM Builder scripts, and follow their live output directly inside A-Team Agent.": "配置构建、运行现有 ROM 构建脚本，并在 A-Team Agent 中查看实时输出。",
  "Refresh configuration": "刷新配置", "Load Configuration": "加载配置",
  "Build configuration": "构建配置", "Build Console": "构建控制台", "Build console": "构建控制台",
  "Settings are sent to the local Agent backend and validated before a script can run.": "设置会发送到本地 Agent 后端，并在脚本运行前进行验证。",
  "Android source directory": "Android 源码目录", "Browse": "浏览",
  "Device": "设备", "Android version": "Android 版本", "Known ROM build command": "已知 ROM 构建命令",
  "Build variant": "构建类型", "GApps variant": "GApps 类型", "Clean variant": "清理类型",
  "Installer variant": "安装程序类型", "Build jobs": "构建任务数", "Use ccache": "使用 ccache",
  "Custom APN": "自定义 APN", "Build ROM": "构建 ROM", "Sync source": "同步源码",
  "Sync GApps": "同步 GApps", "Clean": "清理", "A-Team setup": "A-Team 设置", "Upload build": "上传构建",
  "Resource monitor": "资源监视器", "Agent integration": "Agent 集成",
  "Original ROM Builder terminal monitor": "原始 ROM Builder 终端监视器",
  "Monitor is installed on the Agent host.": "Agent 主机已安装监视器。",
  "Install btop or bpytop on the Agent host to use the original monitor.": "请在 Agent 主机上安装 btop 或 bpytop 以使用原始监视器。",
  "Launch monitor": "启动监视器", "Launching…": "正在启动…",
  "The original ROM Builder uses btop, with bpytop as a fallback. It runs in a desktop terminal because this browser pane cannot directly host an interactive system PTY.": "原始 ROM Builder 使用 btop，并以 bpytop 作为备用。由于浏览器面板无法直接承载交互式系统 PTY，监视器将在桌面终端中运行。",
  "No task has been started yet.": "尚未启动任务。", "ROM Builder output will appear here when you start a task.": "启动任务后，ROM Builder 输出将在此处显示。",
  "Waiting for resource metrics…": "正在等待资源指标…",
  "CPU load": "CPU 负载", "logical CPUs": "逻辑 CPU", "Memory used": "已用内存",
  "total": "总计", "Disk free": "可用磁盘", "Disk metrics unavailable": "磁盘指标不可用",
  "Host": "主机", "Updated": "更新时间", "Refreshes every 5 seconds.": "每 5 秒刷新。",
};
function rb(text: string, locale: string) { return locale.toLowerCase().startsWith("zh") ? (ROM_BUILDER_ZH[text] ?? text) : text; }

const actions = [
  { id: "build", label: "Build ROM", icon: Play, description: "Run the configured Android ROM build." },
  { id: "sync", label: "Sync source", icon: RefreshCw, description: "Run the device-source sync workflow." },
  { id: "gapps-sync", label: "Sync GApps", icon: Layers3, description: "Run the existing GApps sync workflow." },
  { id: "clean", label: "Clean", icon: Wrench, description: "Run the configured clean workflow." },
  { id: "setup", label: "A-Team setup", icon: Settings2, description: "Run the bundled A-Team setup script." },
  { id: "upload", label: "Upload build", icon: HardDrive, description: "Run the configured upload workflow." },
] as const;

export default function RomBuilderWorkspacePage() {
  const { locale } = useI18n();
  const [moduleAvailable, setModuleAvailable] = useState<boolean | null>(null);
  const [devices, setDevices] = useState<Device[]>([]);
  const [hosts, setHosts] = useState<Host[]>([]);
  const [buildCommands, setBuildCommands] = useState<BuildCommand[]>([]);
  const [buildCommand, setBuildCommand] = useState("default");
  const [device, setDevice] = useState("");
  const [romPath, setRomPath] = useState("");
  const [androidVersion, setAndroidVersion] = useState("16");
  const [buildVariant, setBuildVariant] = useState("userdebug");
  const [gappsVariant, setGappsVariant] = useState("vanilla");
  const [cleanVariant, setCleanVariant] = useState("full");
  const [installerVariant, setInstallerVariant] = useState("custom");
  const [buildJobs, setBuildJobs] = useState("6");
  const [useCcache, setUseCcache] = useState(true);
  const [customApn, setCustomApn] = useState(false);
  const [job, setJob] = useState<Job | null>(null);
  const [resources, setResources] = useState<ResourceSnapshot | null>(null);
  const [log, setLog] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loadingConfig, setLoadingConfig] = useState(true);
  const [startingAction, setStartingAction] = useState<string | null>(null);
  const logOffset = useRef(0);
  const terminalRef = useRef<HTMLPreElement>(null);

  const refreshConfig = useCallback(async () => {
    setLoadingConfig(true);
    setError(null);
    try {
      const [deviceResponse, hostResponse, commandResponse] = await Promise.all([
        fetch("/api/rom-builder/devices", { cache: "no-store" }),
        fetch("/api/rom-builder/hosts", { cache: "no-store" }),
        fetch("/api/rom-builder/commands", { cache: "no-store" }),
      ]);
      const deviceData = await deviceResponse.json() as { devices?: Device[]; error?: string };
      const hostData = await hostResponse.json() as { hosts?: Host[]; error?: string };
      const commandData = await commandResponse.json() as { commands?: BuildCommand[]; error?: string };
      if (!deviceResponse.ok) throw new Error(deviceData.error || "Could not load device configurations.");
      if (!hostResponse.ok) throw new Error(hostData.error || "Could not load build hosts.");
      if (!commandResponse.ok) throw new Error(commandData.error || "Could not load build commands.");
      const available = deviceData.devices ?? [];
      setBuildCommands(commandData.commands ?? []);
      setDevices(available);
      setDevice((current) => current || available[0]?.name || "");
      setHosts(hostData.hosts ?? []);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not load ROM Builder configuration.");
    } finally {
      setLoadingConfig(false);
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/modules", { cache: "no-store" })
      .then((response) => response.ok ? response.json() : { modules: [] })
      .then((data: { modules?: Array<{ id: string }> }) => {
        const found = (data.modules ?? []).some((module) => module.id === "rom-builder");
        if (!cancelled) {
          setModuleAvailable(found);
          if (found) void refreshConfig();
        }
      })
      .catch(() => { if (!cancelled) setModuleAvailable(false); });
    return () => { cancelled = true; };
  }, [refreshConfig]);

  useEffect(() => {
    let cancelled = false;
    const refreshResources = async () => {
      try {
        const response = await fetch("/api/rom-builder/resources", { cache: "no-store" });
        if (!response.ok) return;
        const data = await response.json() as ResourceSnapshot;
        if (!cancelled) setResources(data);
      } catch { /* Keep the last successful sample visible. */ }
    };
    void refreshResources();
    const timer = window.setInterval(() => { void refreshResources(); }, 5000);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, []);

  const startAction = async (action: string) => {
    setStartingAction(action);
    setError(null);
    try {
      const response = await fetch("/api/rom-builder/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action,
          payload: {
            device, rom_path: romPath, android_version: androidVersion,
            build_variant: buildVariant, build_command: buildCommand, gapps_variant: gappsVariant,
            clean_variant: cleanVariant, installer_variant: installerVariant,
            build_jobs: Number(buildJobs), use_ccache: useCcache, custom_apn: customApn,
          },
        }),
      });
      const result = await response.json() as Job & { error?: string };
      if (!response.ok) throw new Error(result.error || "Could not start ROM Builder task.");
      setJob(result);
      setLog("");
      logOffset.current = 0;
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not start ROM Builder task.");
    } finally {
      setStartingAction(null);
    }
  };

  useEffect(() => {
    if (!job || !["queued", "running"].includes(job.status)) return;
    let cancelled = false;
    const poll = async () => {
      try {
        const response = await fetch(`/api/rom-builder/jobs?id=${encodeURIComponent(job.id)}&offset=${logOffset.current}`, { cache: "no-store" });
        const data = await response.json() as { status?: Job; logs?: { text?: string; next_offset?: number }; error?: string };
        if (!response.ok) throw new Error(data.error || "Could not read job status.");
        if (cancelled) return;
        if (data.logs?.text) setLog((current) => current + data.logs!.text);
        if (typeof data.logs?.next_offset === "number") logOffset.current = data.logs.next_offset;
        if (data.status) setJob(data.status);
      } catch (cause) {
        if (!cancelled) setError(cause instanceof Error ? cause.message : "Could not read job status.");
      }
    };
    void poll();
    const timer = window.setInterval(() => { void poll(); }, 1500);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, [job?.id, job?.status]);

  useEffect(() => {
    if (terminalRef.current) terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
  }, [log]);

  const cancelJob = async () => {
    if (!job) return;
    try {
      const response = await fetch(`/api/rom-builder/jobs?id=${encodeURIComponent(job.id)}`, { method: "DELETE" });
      const result = await response.json() as Job & { error?: string };
      if (!response.ok) throw new Error(result.error || "Could not cancel task.");
      setJob(result);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not cancel task.");
    }
  };

  const remoteHosts = hosts.filter((host) => host.kind === "remote");
  const busy = Boolean(job && ["queued", "running"].includes(job.status));

  if (moduleAvailable !== true) return null;

  return (
    <main className="rom-builder-transparency mx-auto flex w-full max-w-7xl flex-col gap-6 p-4 md:p-8">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground"><Cpu className="size-4" /> A-Team Add-on Tools</div>
          <h1 className="text-3xl font-semibold tracking-tight">{rb("ROM Builder", locale)}</h1>
          <p className="max-w-3xl text-muted-foreground">{rb("Configure a build, run the existing ROM Builder scripts, and follow their live output directly inside A-Team Agent.", locale)}</p>
        </div>
        <div className="flex flex-wrap gap-2"><Button variant="outline" onClick={() => void refreshConfig()} disabled={loadingConfig}><RefreshCw className="mr-2 size-4" /> Refresh configuration</Button><Button variant="outline" onClick={() => void refreshConfig()} disabled={loadingConfig}><Settings2 className="mr-2 size-4" /> Load Configuration</Button></div>
      </header>

      {error ? <div role="alert" className="rounded-lg border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm">{error}</div> : null}

      <div className="grid items-start gap-6 xl:grid-cols-2">
        <div className="contents">
          <Card className="order-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Settings2 className="size-5" /> {rb("Build configuration", locale)}</CardTitle>
              <CardDescription>{rb("Settings are sent to the local Agent backend and validated before a script can run.", locale)}</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="rom-path">{rb("Android source directory", locale)}</Label>
                <div className="flex items-center gap-2">
                  <Button type="button" variant="outline" onClick={async () => {
                    setError(null);
                    try {
                      const response = await fetch("/api/rom-builder/browse", { method: "POST" });
                      const result = await response.json() as { path?: string; error?: string };
                      if (!response.ok || !result.path) throw new Error(result.error || "Could not select a folder.");
                      setRomPath(result.path);
                    } catch (cause) {
                      setError(cause instanceof Error ? cause.message : "Could not select a folder.");
                    }
                  }}>{rb("Browse", locale)}</Button>
                  <Input id="rom-path" className="min-w-0 flex-1" placeholder="/home/user/Android/lineage" value={romPath} onChange={(e) => setRomPath(e.target.value)} />
                </div>
                <p className="text-xs text-muted-foreground">Enter the full path on the machine running the Agent. The folder must contain build/ and device/.</p>
              </div>
              <div className="space-y-2">
                <Label>{rb("Device", locale)}</Label>
                <Select value={device} onValueChange={setDevice} disabled={loadingConfig || devices.length === 0}>
                  <SelectTrigger><SelectValue placeholder="Select device" /></SelectTrigger>
                  <SelectContent>{devices.map((item) => <SelectItem key={item.name} value={item.name}>{item.display} ({item.codename})</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{rb("Android version", locale)}</Label>
                <Select value={androidVersion} onValueChange={setAndroidVersion}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{["14", "15", "16", "17"].map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label>{rb("Known ROM build command", locale)}</Label>
                <Select value={buildCommand} onValueChange={setBuildCommand}>
                  <SelectTrigger><SelectValue placeholder="Default from rom.conf" /></SelectTrigger>
                  <SelectContent>{buildCommands.map((item) => <SelectItem key={`${item.id}-${item.label}`} value={item.id}>{item.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{rb("Build variant", locale)}</Label>
                <Select value={buildVariant} onValueChange={setBuildVariant}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{["userdebug", "user", "eng"].map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{rb("GApps variant", locale)}</Label>
                <Select value={gappsVariant} onValueChange={setGappsVariant}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{["vanilla", "gapps", "micro-g", "foss"].map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{rb("Clean variant", locale)}</Label>
                <Select value={cleanVariant} onValueChange={setCleanVariant}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{["full", "lite", "none"].map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{rb("Installer variant", locale)}</Label>
                <Select value={installerVariant} onValueChange={setInstallerVariant}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{["custom", "default"].map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Build jobs</Label>
                <Input type="number" min="1" max="128" value={buildJobs} onChange={(e) => setBuildJobs(e.target.value)} />
              </div>
              <div className="flex items-center justify-between gap-3 rounded-lg border p-3">
                <Label htmlFor="use-ccache">{rb("Use ccache", locale)}</Label>
                <Switch id="use-ccache" checked={useCcache} onCheckedChange={setUseCcache} />
              </div>
              <div className="flex items-center justify-between gap-3 rounded-lg border p-3">
                <Label htmlFor="custom-apn">{rb("Custom APN", locale)}</Label>
                <Switch id="custom-apn" checked={customApn} onCheckedChange={setCustomApn} />
              </div>
              <div className="sm:col-span-2 flex flex-wrap gap-2 pt-2">
                {actions.map(({ id, label, icon: Icon }) => (
                  <Button key={id} variant={id === "clean" ? "outline" : "default"} onClick={() => void startAction(id)} disabled={loadingConfig || busy || Boolean(startingAction) || !device || !romPath.trim()}>
                    <Icon className="mr-2 size-4" /> {startingAction === id ? "Starting…" : label}
                  </Button>
                ))}
              </div>
              {remoteHosts.length ? <p className="sm:col-span-2 text-xs text-muted-foreground">Remote hosts found in configuration: {remoteHosts.map((host) => host.name).join(", ")}. Remote execution will be enabled after SSH credential and remote-path handling is ported; these actions currently run on the Agent host.</p> : null}
            </CardContent>
          </Card>

          <Card className="order-3">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Monitor className="size-5" /> {rb("Resource monitor", locale)}</CardTitle>
              <CardDescription>{rb("Original ROM Builder terminal monitor", locale)}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <div className="rounded-lg border p-3">
                  <p className="text-xs text-muted-foreground">{rb("CPU load", locale)}</p>
                  <p className="text-lg font-semibold tabular-nums">{resources ? resources.loadAverage.map((value) => value.toFixed(2)).join(" / ") : "—"}</p>
                  <p className="text-xs text-muted-foreground">{resources ? `${resources.cpuCount} ${rb("logical CPUs", locale)}` : rb("Waiting for resource metrics…", locale)}</p>
                </div>
                <div className="rounded-lg border p-3">
                  <p className="text-xs text-muted-foreground">{rb("Memory used", locale)}</p>
                  <p className="text-lg font-semibold tabular-nums">{resources ? `${Math.round(resources.memory.used / 1024 / 1024 / 1024 * 10) / 10} GB` : "—"}</p>
                  <p className="text-xs text-muted-foreground">{resources ? `${Math.round(resources.memory.total / 1024 / 1024 / 1024 * 10) / 10} GB ${rb("total", locale)}` : ""}</p>
                </div>
                <div className="rounded-lg border p-3">
                  <p className="text-xs text-muted-foreground">{rb("Disk free", locale)}</p>
                  <p className="text-lg font-semibold tabular-nums">{resources?.disk ? `${Math.round(resources.disk.free / 1024 / 1024 / 1024 * 10) / 10} GB` : "—"}</p>
                  <p className="text-xs text-muted-foreground">{resources?.disk ? `${Math.round(resources.disk.total / 1024 / 1024 / 1024 * 10) / 10} GB ${rb("total", locale)}` : rb("Disk metrics unavailable", locale)}</p>
                </div>
                <div className="rounded-lg border p-3">
                  <p className="text-xs text-muted-foreground">{rb("Host", locale)}</p>
                  <p className="truncate text-lg font-semibold" title={resources?.hostname}>{resources?.hostname ?? "—"}</p>
                  <p className="truncate text-xs text-muted-foreground">{resources?.platform ?? ""}</p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">{resources ? `${rb("Updated", locale)} ${new Date(resources.sampledAt).toLocaleTimeString()}. ${rb("Refreshes every 5 seconds.", locale)}` : rb("Waiting for resource metrics…", locale)}</p>
            </CardContent>
          </Card>

          <Card className="order-4">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><HardDrive className="size-5" /> {rb("Agent integration", locale)}</CardTitle>
              <CardDescription>The Agent now owns the workflow and calls the bundled ROM Builder scripts.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-muted-foreground">
              <p>Build and sync actions run through an allow-listed CLI. Configuration is validated, job state is persisted, and stdout/stderr are collected for live display.</p>
              <p>Application updates are handled by the Agent updater. There is no separate ROM Builder updater.</p>
            </CardContent>
          </Card>
        </div>

        <div className="contents">
          <Card className="order-2 xl:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><TerminalSquare className="size-5" /> {rb("Build console", locale)}</CardTitle>
              <CardDescription>Live script output and task status.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {job ? (
                <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border p-3">
                  <div>
                    <p className="font-medium capitalize">{job.action.replace("-", " ")}</p>
                    <p className="text-xs text-muted-foreground">{job.message || job.status} · {job.status}</p>
                  </div>
                  {busy ? <Button variant="destructive" size="sm" onClick={() => void cancelJob()}><Square className="mr-2 size-3" /> Cancel task</Button> : null}
                </div>
              ) : <p className="text-sm text-muted-foreground">{rb("No task has been started yet.", locale)}</p>}
              <pre ref={terminalRef} className="h-[480px] overflow-auto rounded-lg border bg-[#0b0f14] p-4 font-mono text-xs leading-relaxed text-[#d8e2ed] whitespace-pre-wrap break-words">{log || "ROM Builder output will appear here when you start a task."}</pre>
              {job && !busy && job.status !== "succeeded" ? <p className="text-sm text-destructive">Task ended with status: {job.status}{job.exit_code !== undefined && job.exit_code !== null ? ` (exit ${job.exit_code})` : ""}</p> : null}
              {job?.status === "succeeded" ? <p className="text-sm text-emerald-500">Task completed successfully.</p> : null}
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}
