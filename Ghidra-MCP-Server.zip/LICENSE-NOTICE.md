# Third-party components

This module downloads, but does not redistribute inside the source archive:

- Ghidra 12.1.4 from the National Security Agency's official GitHub release.
- GhidraMCP 7.0.0 extension and Python bridge from https://github.com/bethington/ghidra-mcp.

Review and comply with the upstream licenses and notices before use. Ghidra is distributed under its own license; GhidraMCP is Apache-2.0. The A-Team installer pins and verifies the release artifacts but does not claim ownership of either project.
