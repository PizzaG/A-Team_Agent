#!/usr/bin/env python3
"""Install, launch and connect the pinned Ghidra 12.1.4 + GhidraMCP 7.0.0 stack.

All downloaded artifacts are SHA-256 verified before extraction/installation.
This script is intentionally non-executable by default; invoke it with Python.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Any

MODULE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = MODULE_DIR.parents[1]
RUNTIME_DIR = MODULE_DIR / "runtime"
DOWNLOAD_DIR = MODULE_DIR / "downloads"
VENV_DIR = MODULE_DIR / ".venv"
GHIDRA_VERSION = "12.1.4"
GHIDRA_DIR_NAME = "ghidra_12.1.4_PUBLIC"
GHIDRA_URL = "https://github.com/NationalSecurityAgency/ghidra/releases/download/Ghidra_12.1.4_build/ghidra_12.1.4_PUBLIC_20260921.zip"
GHIDRA_SHA256 = "ddac49f903da9d5bac833e5cc79395098b9c33cfd3279be5f31bd00387d2d4db"
MCP_RELEASE = "7.0.0"
EXTENSION_URL = "https://github.com/bethington/ghidra-mcp/releases/download/v7.0.0/GhidraMCP-7.0.0.zip"
EXTENSION_SHA256 = "d133c4c869a0d9f605c1c9426bf5d9064772a6947ccecde0f42fbbffecf1d812"
WHEEL_URL = "https://github.com/bethington/ghidra-mcp/releases/download/v7.0.0/ghidra_mcp_bridge-7.0.0-py3-none-any.whl"
WHEEL_SHA256 = "a75050061d0d1514d4b11e6288ea7575c09ab6125a1394c33fe349fb7658bbae"
HEALTH_URL = "http://127.0.0.1:8089/check_connection"
SERVER_NAME = "ghidra-mcp"


def log(message: str) -> None:
    print(f"[Ghidra] {message}", flush=True)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download_verified(url: str, destination: Path, expected: str) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_file() and sha256(destination) == expected:
        log(f"Verified cached artifact: {destination.name}")
        return destination
    partial = destination.with_suffix(destination.suffix + ".part")
    partial.unlink(missing_ok=True)
    request = urllib.request.Request(url, headers={"User-Agent": "A-Team-Agent-Ghidra-Module/1.0"})
    log(f"Downloading {destination.name}; this may take several minutes...")
    try:
        with urllib.request.urlopen(request, timeout=60) as response, partial.open("wb") as output:
            shutil.copyfileobj(response, output, length=1024 * 1024)
    except Exception:
        partial.unlink(missing_ok=True)
        raise
    actual = sha256(partial)
    if actual != expected:
        partial.unlink(missing_ok=True)
        raise RuntimeError(f"SHA-256 mismatch for {destination.name}: expected {expected}, received {actual}")
    partial.replace(destination)
    log(f"SHA-256 verified: {destination.name}")
    return destination


def safe_extract(archive: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    with zipfile.ZipFile(archive) as zf:
        entries = zf.infolist()
        for info in entries:
            target = (destination / info.filename).resolve()
            if target != root and root not in target.parents:
                raise RuntimeError(f"Unsafe path in downloaded archive: {info.filename}")
        for info in entries:
            if info.is_dir():
                (destination / info.filename).mkdir(parents=True, exist_ok=True)
                continue
            target = destination / info.filename
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as source, target.open("wb") as output:
                shutil.copyfileobj(source, output)
            # Preserve executable bits only when explicitly present in the verified archive.
            archived_mode = (info.external_attr >> 16) & 0o777
            if archived_mode & 0o111:
                target.chmod(archived_mode)


def ghidra_home() -> Path:
    return RUNTIME_DIR / GHIDRA_DIR_NAME


def ghidra_launcher() -> Path:
    if os.name == "nt":
        return ghidra_home() / "ghidraRun.bat"
    return ghidra_home() / "ghidraRun"


def python_venv_executable() -> Path:
    return VENV_DIR / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def bridge_executable() -> Path:
    return VENV_DIR / ("Scripts/bridge-mcp-ghidra.exe" if os.name == "nt" else "bin/bridge-mcp-ghidra")


def extension_profile_dir() -> Path:
    version_folder = f"ghidra_{GHIDRA_VERSION}_PUBLIC"
    if os.name == "nt":
        base_dir = Path(os.environ.get("APPDATA", Path.home() / "AppData/Roaming")) / "ghidra"
    elif sys.platform == "darwin":
        base_dir = Path.home() / "Library/ghidra"
    else:
        base_dir = Path.home() / ".config/ghidra"
    return base_dir / version_folder / "Extensions"


def check_java() -> None:
    try:
        result = subprocess.run(["java", "-version"], capture_output=True, text=True, timeout=10)
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError("Java 21 is required. Install an OpenJDK 21 runtime and ensure `java` is on PATH.") from exc
    output = (result.stderr or result.stdout).splitlines()
    version_text = " ".join(output[:2])
    if result.returncode != 0 or not any(token in version_text for token in ('"21', ' 21', 'version "21')):
        raise RuntimeError(f"Java 21 is required; detected: {version_text or 'unknown'}")
    log(f"Java runtime: {version_text}")


def install() -> None:
    if sys.version_info < (3, 10):
        raise RuntimeError("Python 3.10 or newer is required for the Ghidra MCP bridge.")
    check_java()
    ghidra_zip = download_verified(GHIDRA_URL, DOWNLOAD_DIR / "ghidra_12.1.4_PUBLIC_20260921.zip", GHIDRA_SHA256)
    extension_zip = download_verified(EXTENSION_URL, DOWNLOAD_DIR / f"GhidraMCP-{MCP_RELEASE}.zip", EXTENSION_SHA256)
    wheel = download_verified(WHEEL_URL, DOWNLOAD_DIR / f"ghidra_mcp_bridge-{MCP_RELEASE}-py3-none-any.whl", WHEEL_SHA256)

    if not ghidra_home().is_dir():
        log("Extracting Ghidra into the module runtime directory...")
        safe_extract(ghidra_zip, RUNTIME_DIR)
    if not ghidra_launcher().exists():
        raise RuntimeError(f"Ghidra launcher not found after extraction: {ghidra_launcher()}")
    if os.name != "nt" and not os.access(ghidra_launcher(), os.X_OK):
        # This is the one verified vendor launcher that must be executable;
        # do not chmod the module's own Python scripts or arbitrary extracted files.
        ghidra_launcher().chmod(0o755)

    profile = extension_profile_dir()
    log(f"Installing GhidraMCP extension into user extension profile: {profile}")
    safe_extract(extension_zip, profile)
    # Some release zips wrap the extension in a top-level GhidraMCP directory;
    # Ghidra expects that folder directly under Extensions.
    wrapped = profile / "GhidraMCP" / "GhidraMCP"
    if wrapped.is_dir() and not (profile / "GhidraMCP" / "extension.properties").exists():
        for child in wrapped.iterdir():
            target = profile / "GhidraMCP" / child.name
            if target.exists():
                if target.is_dir():
                    shutil.rmtree(target)
                else:
                    target.unlink()
            shutil.move(str(child), str(target))
        wrapped.rmdir()

    if not python_venv_executable().exists():
        log("Creating isolated Python environment for the MCP bridge...")
        subprocess.run([sys.executable, "-m", "venv", str(VENV_DIR)], check=True)
    log("Installing pinned Ghidra MCP bridge wheel...")
    subprocess.run([str(python_venv_executable()), "-m", "pip", "install", "--disable-pip-version-check", str(wheel)], check=True)
    write_mcp_config(enabled=True)
    log("Install complete. Open Ghidra once and enable GhidraMCPPlugin under File > Configure > Utility > Configure.")
    log("Then restart Ghidra and verify the local server with: python modules/Ghidra/ghidra.py status")


def launch() -> None:
    launcher = ghidra_launcher()
    if not launcher.exists():
        raise RuntimeError("Ghidra is not installed in this module yet. Run: python modules/Ghidra/ghidra.py install")
    if os.name == "nt":
        subprocess.Popen(["cmd.exe", "/c", str(launcher)], cwd=str(ghidra_home()), close_fds=True)
    else:
        if not os.access(launcher, os.X_OK):
            raise RuntimeError(f"Ghidra launcher is not executable: {launcher}. Re-run install after checking archive permissions.")
        subprocess.Popen([str(launcher)], cwd=str(ghidra_home()), start_new_session=True, close_fds=True)
    log("Ghidra launch requested.")


def status() -> int:
    request = urllib.request.Request(HEALTH_URL, headers={"Accept": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=3) as response:
            payload = json.loads(response.read().decode("utf-8"))
        log(f"Ghidra MCP connected: {json.dumps(payload, sort_keys=True)}")
        return 0
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        log(f"Ghidra MCP is not reachable at {HEALTH_URL}: {exc}")
        return 1


def write_mcp_config(enabled: bool) -> Path:
    config_path = Path(os.environ.get("DEER_FLOW_EXTENSIONS_CONFIG_PATH", PROJECT_ROOT / "extensions_config.json"))
    config_path.parent.mkdir(parents=True, exist_ok=True)
    if config_path.exists():
        try:
            config: dict[str, Any] = json.loads(config_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Refusing to overwrite invalid MCP config: {config_path}") from exc
        backup = config_path.with_suffix(config_path.suffix + ".before-ghidra")
        if not backup.exists():
            shutil.copy2(config_path, backup)
    else:
        config = {"middlewares": [], "mcpInterceptors": [], "mcpServers": {}, "skills": {}}
    servers = config.setdefault("mcpServers", {})
    if not isinstance(servers, dict):
        raise RuntimeError("extensions_config.json has an invalid mcpServers section; refusing to modify it.")
    servers[SERVER_NAME] = {
        "enabled": enabled,
        "type": "stdio",
        "command": str(bridge_executable()),
        "args": [],
        "env": {"GHIDRA_MCP_URL": "http://127.0.0.1:8089", "GHIDRA_MCP_ALLOW_SCRIPTS": "0"},
        "tool_name_prefix": True,
        "session_init_timeout": 30,
        "tool_call_timeout": 120,
        "description": "Ghidra 12.1.4 reverse engineering tools via the local GhidraMCP extension."
    }
    temp = config_path.with_suffix(config_path.suffix + ".tmp")
    temp.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    temp.replace(config_path)
    log(f"MCP server config {'enabled' if enabled else 'disabled'} in {config_path}")
    return config_path


def main() -> int:
    parser = argparse.ArgumentParser(description="Manage the A-Team Ghidra 12.1.4 module.")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("install", help="Download, verify and install Ghidra + GhidraMCP + isolated bridge.")
    sub.add_parser("launch", help="Launch the module-local Ghidra GUI.")
    sub.add_parser("status", help="Check the local Ghidra MCP HTTP health endpoint.")
    sub.add_parser("configure-mcp", help="Register/enable Ghidra MCP tools in extensions_config.json.")
    sub.add_parser("disable-mcp", help="Disable the Ghidra MCP server entry without deleting it.")
    args = parser.parse_args()
    try:
        if args.command == "install":
            install()
        elif args.command == "launch":
            launch()
        elif args.command == "status":
            return status()
        elif args.command == "configure-mcp":
            write_mcp_config(enabled=True)
        elif args.command == "disable-mcp":
            write_mcp_config(enabled=False)
        return 0
    except (OSError, RuntimeError, subprocess.CalledProcessError, zipfile.BadZipFile) as exc:
        log(f"ERROR: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
