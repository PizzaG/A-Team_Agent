# A-Team Ghidra Module

This module installs and manages the official Ghidra 12.1.4 application locally and connects its GUI extension to A-Team through the upstream GhidraMCP 7.0.0 bridge.

The large Ghidra distribution is intentionally downloaded into `runtime/` on first install rather than bundled in the A-Team source ZIP. The pinned official release is approximately 570 MB. The module verifies SHA-256 digests for Ghidra, the extension ZIP, and the Python bridge wheel before use.

## Quick start

The A-Team launcher creates the persistent agent workspace if needed. When the Ghidra setup skill runs, it resolves the currently installed add-on under the application root `modules/` directory and copies the installer/metadata into `/mnt/user-data/workspace/modules/Ghidra/`. This happens at skill runtime, so installing the add-on in the app does not require restarting the agent. The agent runs setup from that workspace. For manual setup, run the commands below from `/mnt/user-data/workspace` (or use the equivalent module path in your own deployment). The first command downloads the full Ghidra distribution (about 570 MB), the matching GhidraMCP extension and the Python bridge wheel. All release artifacts are SHA-256 verified.

```bash
# 1. Confirm Java 21 LTS and Python 3.10+ are installed.
java -version
python --version

# 2. Download and install Ghidra, the GUI extension and isolated bridge.
python modules/Ghidra/ghidra.py install

# 3. Launch the module-local native Ghidra GUI.
python modules/Ghidra/ghidra.py launch
```

Then, in Ghidra's **Project Window**:

1. Open **File → Configure → Utility → Configure**.
2. Enable **GhidraMCPPlugin**, then click **OK** and **Close**.
3. Save the tool configuration if prompted and restart Ghidra if requested.

Back in `/mnt/user-data/workspace`, verify the plugin server and register the bridge:

```bash
# 4. Verify the local plugin HTTP endpoint.
python modules/Ghidra/ghidra.py status

# 5. Register/enable the bridge in A-Team's extensions_config.json.
python modules/Ghidra/ghidra.py configure-mcp
```

Reload/restart the A-Team agent tool session to refresh its MCP tool catalog. Do not report setup as complete until `status` succeeds and bridge registration succeeds.

### Prerequisites and platform notes

- Java 21 LTS (the installer checks `java -version`; other major versions are rejected).
- Python 3.10 or newer available as `python`.
- Internet access and sufficient disk space for the approximately 570 MB Ghidra archive, extraction and bridge environment.
- The Ghidra distribution is installed in `modules/Ghidra/runtime/`; it is not bundled in the source ZIP.
- Windows launches `ghidraRun.bat`; Linux/macOS launch `ghidraRun`.
- On Linux/macOS, the verified vendor launcher is made executable if needed. The module's own Python source remains non-executable and must be invoked with `python`.

If Java 21 is not installed, install an OpenJDK 21 LTS distribution appropriate for the host OS, then rerun the preflight commands. The module does not silently replace the system Java installation.

See `../../skills/public/ghidra-reverse-engineering/SKILL.md` for the agent-driven setup sequence and mandatory script-permission safeguards.


## Layout

- `ghidra.py` — verified installer, launcher, health check and MCP registration CLI.
- `runtime/` — full extracted Ghidra distribution (created by install).
- `downloads/` — verified upstream release artifacts (created by install).
- `.venv/` — isolated Python environment containing `bridge-mcp-ghidra` (created by install).

The Ghidra GUI remains a native desktop window. A-Team controls it through the local HTTP API/MCP bridge; the browser workspace can render analysis results but does not embed the Swing desktop UI.

## Security

The bridge is bound to loopback (`127.0.0.1`). Script execution is explicitly disabled in the generated MCP configuration. Do not enable it without reviewing a specific script and obtaining the user's approval. The installer rejects unsafe ZIP paths and does not set executable permissions on the module's Python source files.
